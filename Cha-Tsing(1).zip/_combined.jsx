
// ═══ android-frame.jsx ═══

// Android.jsx — Simplified Android (Material 3) device frame
// Status bar + top app bar + content + gesture nav + keyboard.
// Based on Figma M3 spec. No dependencies, no image assets.

const MD_C = {
  surface: '#f4fbf8',
  surfaceVariant: '#dae5e1',
  inverseOnSurface: '#ecf2ef',
  secondaryContainer: '#cde8e1',
  primaryFixedDim: '#83d5c6',
  onSurface: '#171d1b',
  onSurfaceVar: '#49454f',
  onPrimaryContainer: '#00201c',
  primary: '#006a60',
  frameBorder: 'rgba(116,119,117,0.5)',
};

// ─────────────────────────────────────────────────────────────
// Status bar (time left, wifi/cell/battery right)
// ─────────────────────────────────────────────────────────────
function AndroidStatusBar({ dark = false }) {
  const c = dark ? '#fff' : MD_C.onSurface;
  return (
    <div style={{
      height: 40, display: 'flex', alignItems: 'center',
      justifyContent: 'space-between', padding: '0 16px',
      position: 'relative',
      fontFamily: 'Roboto, system-ui, sans-serif',
    }}>
      {/* time left */}
      <div style={{ width: 128, display: 'flex', alignItems: 'center', gap: 8 }}>
        <span style={{ fontSize: 14, fontWeight: 400, letterSpacing: 0.25, lineHeight: '20px', color: c }}>9:30</span>
      </div>
      {/* camera punch-hole (center) */}
      <div style={{
        position: 'absolute', left: '50%', top: 8, transform: 'translateX(-50%)',
        width: 24, height: 24, borderRadius: 100, background: '#2e2e2e',
      }} />
      {/* status icons right */}
      <div style={{ display: 'flex', alignItems: 'center' }}>
        <div style={{ display: 'flex', paddingRight: 2 }}>
          <svg width="16" height="16" viewBox="0 0 16 16" style={{ marginRight: -2 }}>
            <path d="M8 13.3L.67 5.97a10.37 10.37 0 0114.66 0L8 13.3z" fill={c}/>
          </svg>
          <svg width="16" height="16" viewBox="0 0 16 16" style={{ marginRight: -2 }}>
            <path d="M14.67 14.67V1.33L1.33 14.67h13.34z" fill={c}/>
          </svg>
        </div>
        <svg width="16" height="16" viewBox="0 0 16 16">
          <rect x="3.75" y="2" width="8.5" height="13" rx="1.5" fill={c}/>
          <rect x="5.5" y="0.9" width="5" height="2" rx="0.5" fill={c}/>
        </svg>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Top app bar (Material 3 small/medium)
// ─────────────────────────────────────────────────────────────
function AndroidAppBar({ title = 'Title', large = false }) {
  const iconDot = (
    <div style={{
      width: 48, height: 48, display: 'flex', alignItems: 'center', justifyContent: 'center',
    }}>
      <div style={{ width: 22, height: 22, borderRadius: '50%', background: MD_C.onSurfaceVar, opacity: 0.3 }} />
    </div>
  );
  return (
    <div style={{ background: MD_C.surface, padding: '4px 4px 0' }}>
      <div style={{ height: 56, display: 'flex', alignItems: 'center', gap: 4 }}>
        {iconDot}
        {!large && (
          <span style={{
            flex: 1, fontSize: 22, fontWeight: 400, color: MD_C.onSurface,
            fontFamily: 'Roboto, system-ui, sans-serif',
          }}>{title}</span>
        )}
        {large && <div style={{ flex: 1 }} />}
        {iconDot}
      </div>
      {large && (
        <div style={{
          padding: '16px 16px 20px',
          fontSize: 28, fontWeight: 400, color: MD_C.onSurface,
          fontFamily: 'Roboto, system-ui, sans-serif',
        }}>{title}</div>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// List item (Material 3)
// ─────────────────────────────────────────────────────────────
function AndroidListItem({ headline, supporting, leading }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 16,
      padding: '12px 16px', minHeight: 56, boxSizing: 'border-box',
      fontFamily: 'Roboto, system-ui, sans-serif',
    }}>
      {leading && (
        <div style={{
          width: 40, height: 40, borderRadius: '50%',
          background: MD_C.primary, color: '#fff',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 18, fontWeight: 500, flexShrink: 0,
        }}>{leading}</div>
      )}
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 16, color: MD_C.onSurface, lineHeight: '24px' }}>{headline}</div>
        {supporting && (
          <div style={{ fontSize: 14, color: MD_C.onSurfaceVar, lineHeight: '20px' }}>{supporting}</div>
        )}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Gesture nav bar (pill)
// ─────────────────────────────────────────────────────────────
function AndroidNavBar({ dark = false }) {
  return (
    <div style={{
      height: 24, display: 'flex', alignItems: 'center', justifyContent: 'center',
    }}>
      <div style={{
        width: 108, height: 4, borderRadius: 2,
        background: dark ? '#fff' : MD_C.onSurface, opacity: 0.4,
      }} />
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Device frame — wraps everything
// ─────────────────────────────────────────────────────────────
function AndroidDevice({
  children, width = 412, height = 892, dark = false,
  title, large = false, keyboard = false,
}) {
  return (
    <div style={{
      width, height, borderRadius: 18, overflow: 'hidden',
      background: dark ? '#1d1b20' : MD_C.surface,
      border: `8px solid ${MD_C.frameBorder}`,
      boxShadow: '0 30px 80px rgba(0,0,0,0.25)',
      display: 'flex', flexDirection: 'column', boxSizing: 'border-box',
    }}>
      <AndroidStatusBar dark={dark} />
      {title !== undefined && <AndroidAppBar title={title} large={large} />}
      <div style={{ flex: 1, overflow: 'auto' }}>
        {children}
      </div>
      {keyboard && <AndroidKeyboard />}
      <AndroidNavBar dark={dark} />
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Keyboard — Gboard (Material 3)
// ─────────────────────────────────────────────────────────────
function AndroidKeyboard() {
  let _k = 0;
  const key = (l, { flex = 1, bg = MD_C.surface, r = 6, minW, fs = 21 } = {}) => (
    <div key={_k++} style={{
      height: 46, borderRadius: r, flex, minWidth: minW,
      background: bg, display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontFamily: 'Roboto, system-ui', fontSize: fs,
      color: MD_C.onPrimaryContainer,
    }}>{l}</div>
  );
  const row = (keys, style = {}) => (
    <div style={{ display: 'flex', gap: 6, justifyContent: 'center', ...style }}>
      {keys.map(l => key(l))}
    </div>
  );
  return (
    <div style={{
      background: MD_C.inverseOnSurface, padding: '0 8px 8px',
      display: 'flex', flexDirection: 'column', gap: 4,
    }}>
      {/* navbar spacer (icons omitted) */}
      <div style={{ height: 44 }} />
      {/* key rows */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        {row(['q','w','e','r','t','y','u','i','o','p'])}
        {row(['a','s','d','f','g','h','j','k','l'], { padding: '0 20px' })}
        <div style={{ display: 'flex', gap: 6 }}>
          {key('', { bg: MD_C.surfaceVariant })}
          <div style={{ display: 'flex', gap: 6, flex: 7, minWidth: 274 }}>
            {['z','x','c','v','b','n','m'].map(l => key(l))}
          </div>
          {key('', { bg: MD_C.surfaceVariant })}
        </div>
        <div style={{ display: 'flex', gap: 6 }}>
          {key('?123', { bg: MD_C.secondaryContainer, r: 100, minW: 58, fs: 14 })}
          {key(',', { bg: MD_C.surfaceVariant })}
          {key('', { flex: 3, minW: 154 })}
          {key('.', { bg: MD_C.surfaceVariant })}
          {key('', { bg: MD_C.primaryFixedDim, r: 100, minW: 58 })}
        </div>
      </div>
    </div>
  );
}

Object.assign(window, {
  AndroidDevice, AndroidStatusBar, AndroidAppBar, AndroidListItem, AndroidNavBar, AndroidKeyboard,
});


// ═══ tweaks-panel.jsx ═══

// tweaks-panel.jsx
// Reusable Tweaks shell + form-control helpers.
//
// Owns the host protocol (listens for __activate_edit_mode / __deactivate_edit_mode,
// posts __edit_mode_available / __edit_mode_set_keys / __edit_mode_dismissed) so
// individual prototypes don't re-roll it. Ships a consistent set of controls so you
// don't hand-draw <input type="range">, segmented radios, steppers, etc.
//
// Usage (in an HTML file that loads React + Babel):
//
//   const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
//     "primaryColor": "#D97757",
//     "fontSize": 16,
//     "density": "regular",
//     "dark": false
//   }/*EDITMODE-END*/;
//
//   function App() {
//     const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
//     return (
//       <div style={{ fontSize: t.fontSize, color: t.primaryColor }}>
//         Hello
//         <TweaksPanel>
//           <TweakSection label="Typography" />
//           <TweakSlider label="Font size" value={t.fontSize} min={10} max={32} unit="px"
//                        onChange={(v) => setTweak('fontSize', v)} />
//           <TweakRadio  label="Density" value={t.density}
//                        options={['compact', 'regular', 'comfy']}
//                        onChange={(v) => setTweak('density', v)} />
//           <TweakSection label="Theme" />
//           <TweakColor  label="Primary" value={t.primaryColor}
//                        onChange={(v) => setTweak('primaryColor', v)} />
//           <TweakToggle label="Dark mode" value={t.dark}
//                        onChange={(v) => setTweak('dark', v)} />
//         </TweaksPanel>
//       </div>
//     );
//   }
//
// ─────────────────────────────────────────────────────────────────────────────

const __TWEAKS_STYLE = `
  .twk-panel{position:fixed;right:16px;bottom:16px;z-index:2147483646;width:280px;
    max-height:calc(100vh - 32px);display:flex;flex-direction:column;
    background:rgba(250,249,247,.78);color:#29261b;
    -webkit-backdrop-filter:blur(24px) saturate(160%);backdrop-filter:blur(24px) saturate(160%);
    border:.5px solid rgba(255,255,255,.6);border-radius:14px;
    box-shadow:0 1px 0 rgba(255,255,255,.5) inset,0 12px 40px rgba(0,0,0,.18);
    font:11.5px/1.4 ui-sans-serif,system-ui,-apple-system,sans-serif;overflow:hidden}
  .twk-hd{display:flex;align-items:center;justify-content:space-between;
    padding:10px 8px 10px 14px;cursor:move;user-select:none}
  .twk-hd b{font-size:12px;font-weight:600;letter-spacing:.01em}
  .twk-x{appearance:none;border:0;background:transparent;color:rgba(41,38,27,.55);
    width:22px;height:22px;border-radius:6px;cursor:default;font-size:13px;line-height:1}
  .twk-x:hover{background:rgba(0,0,0,.06);color:#29261b}
  .twk-body{padding:2px 14px 14px;display:flex;flex-direction:column;gap:10px;
    overflow-y:auto;overflow-x:hidden;min-height:0;
    scrollbar-width:thin;scrollbar-color:rgba(0,0,0,.15) transparent}
  .twk-body::-webkit-scrollbar{width:8px}
  .twk-body::-webkit-scrollbar-track{background:transparent;margin:2px}
  .twk-body::-webkit-scrollbar-thumb{background:rgba(0,0,0,.15);border-radius:4px;
    border:2px solid transparent;background-clip:content-box}
  .twk-body::-webkit-scrollbar-thumb:hover{background:rgba(0,0,0,.25);
    border:2px solid transparent;background-clip:content-box}
  .twk-row{display:flex;flex-direction:column;gap:5px}
  .twk-row-h{flex-direction:row;align-items:center;justify-content:space-between;gap:10px}
  .twk-lbl{display:flex;justify-content:space-between;align-items:baseline;
    color:rgba(41,38,27,.72)}
  .twk-lbl>span:first-child{font-weight:500}
  .twk-val{color:rgba(41,38,27,.5);font-variant-numeric:tabular-nums}

  .twk-sect{font-size:10px;font-weight:600;letter-spacing:.06em;text-transform:uppercase;
    color:rgba(41,38,27,.45);padding:10px 0 0}
  .twk-sect:first-child{padding-top:0}

  .twk-field{appearance:none;width:100%;height:26px;padding:0 8px;
    border:.5px solid rgba(0,0,0,.1);border-radius:7px;
    background:rgba(255,255,255,.6);color:inherit;font:inherit;outline:none}
  .twk-field:focus{border-color:rgba(0,0,0,.25);background:rgba(255,255,255,.85)}
  select.twk-field{padding-right:22px;
    background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='10' height='6' viewBox='0 0 10 6'><path fill='rgba(0,0,0,.5)' d='M0 0h10L5 6z'/></svg>");
    background-repeat:no-repeat;background-position:right 8px center}

  .twk-slider{appearance:none;-webkit-appearance:none;width:100%;height:4px;margin:6px 0;
    border-radius:999px;background:rgba(0,0,0,.12);outline:none}
  .twk-slider::-webkit-slider-thumb{-webkit-appearance:none;appearance:none;
    width:14px;height:14px;border-radius:50%;background:#fff;
    border:.5px solid rgba(0,0,0,.12);box-shadow:0 1px 3px rgba(0,0,0,.2);cursor:default}
  .twk-slider::-moz-range-thumb{width:14px;height:14px;border-radius:50%;
    background:#fff;border:.5px solid rgba(0,0,0,.12);box-shadow:0 1px 3px rgba(0,0,0,.2);cursor:default}

  .twk-seg{position:relative;display:flex;padding:2px;border-radius:8px;
    background:rgba(0,0,0,.06);user-select:none}
  .twk-seg-thumb{position:absolute;top:2px;bottom:2px;border-radius:6px;
    background:rgba(255,255,255,.9);box-shadow:0 1px 2px rgba(0,0,0,.12);
    transition:left .15s cubic-bezier(.3,.7,.4,1),width .15s}
  .twk-seg.dragging .twk-seg-thumb{transition:none}
  .twk-seg button{appearance:none;position:relative;z-index:1;flex:1;border:0;
    background:transparent;color:inherit;font:inherit;font-weight:500;min-height:22px;
    border-radius:6px;cursor:default;padding:4px 6px;line-height:1.2;
    overflow-wrap:anywhere}

  .twk-toggle{position:relative;width:32px;height:18px;border:0;border-radius:999px;
    background:rgba(0,0,0,.15);transition:background .15s;cursor:default;padding:0}
  .twk-toggle[data-on="1"]{background:#34c759}
  .twk-toggle i{position:absolute;top:2px;left:2px;width:14px;height:14px;border-radius:50%;
    background:#fff;box-shadow:0 1px 2px rgba(0,0,0,.25);transition:transform .15s}
  .twk-toggle[data-on="1"] i{transform:translateX(14px)}

  .twk-num{display:flex;align-items:center;height:26px;padding:0 0 0 8px;
    border:.5px solid rgba(0,0,0,.1);border-radius:7px;background:rgba(255,255,255,.6)}
  .twk-num-lbl{font-weight:500;color:rgba(41,38,27,.6);cursor:ew-resize;
    user-select:none;padding-right:8px}
  .twk-num input{flex:1;min-width:0;height:100%;border:0;background:transparent;
    font:inherit;font-variant-numeric:tabular-nums;text-align:right;padding:0 8px 0 0;
    outline:none;color:inherit;-moz-appearance:textfield}
  .twk-num input::-webkit-inner-spin-button,.twk-num input::-webkit-outer-spin-button{
    -webkit-appearance:none;margin:0}
  .twk-num-unit{padding-right:8px;color:rgba(41,38,27,.45)}

  .twk-btn{appearance:none;height:26px;padding:0 12px;border:0;border-radius:7px;
    background:rgba(0,0,0,.78);color:#fff;font:inherit;font-weight:500;cursor:default}
  .twk-btn:hover{background:rgba(0,0,0,.88)}
  .twk-btn.secondary{background:rgba(0,0,0,.06);color:inherit}
  .twk-btn.secondary:hover{background:rgba(0,0,0,.1)}

  .twk-swatch{appearance:none;-webkit-appearance:none;width:56px;height:22px;
    border:.5px solid rgba(0,0,0,.1);border-radius:6px;padding:0;cursor:default;
    background:transparent;flex-shrink:0}
  .twk-swatch::-webkit-color-swatch-wrapper{padding:0}
  .twk-swatch::-webkit-color-swatch{border:0;border-radius:5.5px}
  .twk-swatch::-moz-color-swatch{border:0;border-radius:5.5px}
`;

// ── useTweaks ───────────────────────────────────────────────────────────────
// Single source of truth for tweak values. setTweak persists via the host
// (__edit_mode_set_keys → host rewrites the EDITMODE block on disk).
function useTweaks(defaults) {
  const [values, setValues] = React.useState(defaults);
  // Accepts either setTweak('key', value) or setTweak({ key: value, ... }) so a
  // useState-style call doesn't write a "[object Object]" key into the persisted
  // JSON block.
  const setTweak = React.useCallback((keyOrEdits, val) => {
    const edits = typeof keyOrEdits === 'object' && keyOrEdits !== null
      ? keyOrEdits : { [keyOrEdits]: val };
    setValues((prev) => ({ ...prev, ...edits }));
    window.parent.postMessage({ type: '__edit_mode_set_keys', edits }, '*');
  }, []);
  return [values, setTweak];
}

// ── TweaksPanel ─────────────────────────────────────────────────────────────
// Floating shell. Registers the protocol listener BEFORE announcing
// availability — if the announce ran first, the host's activate could land
// before our handler exists and the toolbar toggle would silently no-op.
// The close button posts __edit_mode_dismissed so the host's toolbar toggle
// flips off in lockstep; the host echoes __deactivate_edit_mode back which
// is what actually hides the panel.
function TweaksPanel({ title = 'Tweaks', children }) {
  const [open, setOpen] = React.useState(false);
  const dragRef = React.useRef(null);
  const offsetRef = React.useRef({ x: 16, y: 16 });
  const PAD = 16;

  const clampToViewport = React.useCallback(() => {
    const panel = dragRef.current;
    if (!panel) return;
    const w = panel.offsetWidth, h = panel.offsetHeight;
    const maxRight = Math.max(PAD, window.innerWidth - w - PAD);
    const maxBottom = Math.max(PAD, window.innerHeight - h - PAD);
    offsetRef.current = {
      x: Math.min(maxRight, Math.max(PAD, offsetRef.current.x)),
      y: Math.min(maxBottom, Math.max(PAD, offsetRef.current.y)),
    };
    panel.style.right = offsetRef.current.x + 'px';
    panel.style.bottom = offsetRef.current.y + 'px';
  }, []);

  React.useEffect(() => {
    if (!open) return;
    clampToViewport();
    if (typeof ResizeObserver === 'undefined') {
      window.addEventListener('resize', clampToViewport);
      return () => window.removeEventListener('resize', clampToViewport);
    }
    const ro = new ResizeObserver(clampToViewport);
    ro.observe(document.documentElement);
    return () => ro.disconnect();
  }, [open, clampToViewport]);

  React.useEffect(() => {
    const onMsg = (e) => {
      const t = e?.data?.type;
      if (t === '__activate_edit_mode') setOpen(true);
      else if (t === '__deactivate_edit_mode') setOpen(false);
    };
    window.addEventListener('message', onMsg);
    window.parent.postMessage({ type: '__edit_mode_available' }, '*');
    return () => window.removeEventListener('message', onMsg);
  }, []);

  const dismiss = () => {
    setOpen(false);
    window.parent.postMessage({ type: '__edit_mode_dismissed' }, '*');
  };

  const onDragStart = (e) => {
    const panel = dragRef.current;
    if (!panel) return;
    const r = panel.getBoundingClientRect();
    const sx = e.clientX, sy = e.clientY;
    const startRight = window.innerWidth - r.right;
    const startBottom = window.innerHeight - r.bottom;
    const move = (ev) => {
      offsetRef.current = {
        x: startRight - (ev.clientX - sx),
        y: startBottom - (ev.clientY - sy),
      };
      clampToViewport();
    };
    const up = () => {
      window.removeEventListener('mousemove', move);
      window.removeEventListener('mouseup', up);
    };
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
  };

  if (!open) return null;
  return (
    <>
      <style>{__TWEAKS_STYLE}</style>
      <div ref={dragRef} className="twk-panel" data-noncommentable=""
           style={{ right: offsetRef.current.x, bottom: offsetRef.current.y }}>
        <div className="twk-hd" onMouseDown={onDragStart}>
          <b>{title}</b>
          <button className="twk-x" aria-label="Close tweaks"
                  onMouseDown={(e) => e.stopPropagation()}
                  onClick={dismiss}>✕</button>
        </div>
        <div className="twk-body">{children}</div>
      </div>
    </>
  );
}

// ── Layout helpers ──────────────────────────────────────────────────────────

function TweakSection({ label, children }) {
  return (
    <>
      <div className="twk-sect">{label}</div>
      {children}
    </>
  );
}

function TweakRow({ label, value, children, inline = false }) {
  return (
    <div className={inline ? 'twk-row twk-row-h' : 'twk-row'}>
      <div className="twk-lbl">
        <span>{label}</span>
        {value != null && <span className="twk-val">{value}</span>}
      </div>
      {children}
    </div>
  );
}

// ── Controls ────────────────────────────────────────────────────────────────

function TweakSlider({ label, value, min = 0, max = 100, step = 1, unit = '', onChange }) {
  return (
    <TweakRow label={label} value={`${value}${unit}`}>
      <input type="range" className="twk-slider" min={min} max={max} step={step}
             value={value} onChange={(e) => onChange(Number(e.target.value))} />
    </TweakRow>
  );
}

function TweakToggle({ label, value, onChange }) {
  return (
    <div className="twk-row twk-row-h">
      <div className="twk-lbl"><span>{label}</span></div>
      <button type="button" className="twk-toggle" data-on={value ? '1' : '0'}
              role="switch" aria-checked={!!value}
              onClick={() => onChange(!value)}><i /></button>
    </div>
  );
}

function TweakRadio({ label, value, options, onChange }) {
  const trackRef = React.useRef(null);
  const [dragging, setDragging] = React.useState(false);
  const opts = options.map((o) => (typeof o === 'object' ? o : { value: o, label: o }));
  const idx = Math.max(0, opts.findIndex((o) => o.value === value));
  const n = opts.length;

  // The active value is read by pointer-move handlers attached for the lifetime
  // of a drag — ref it so a stale closure doesn't fire onChange for every move.
  const valueRef = React.useRef(value);
  valueRef.current = value;

  const segAt = (clientX) => {
    const r = trackRef.current.getBoundingClientRect();
    const inner = r.width - 4;
    const i = Math.floor(((clientX - r.left - 2) / inner) * n);
    return opts[Math.max(0, Math.min(n - 1, i))].value;
  };

  const onPointerDown = (e) => {
    setDragging(true);
    const v0 = segAt(e.clientX);
    if (v0 !== valueRef.current) onChange(v0);
    const move = (ev) => {
      if (!trackRef.current) return;
      const v = segAt(ev.clientX);
      if (v !== valueRef.current) onChange(v);
    };
    const up = () => {
      setDragging(false);
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };

  return (
    <TweakRow label={label}>
      <div ref={trackRef} role="radiogroup" onPointerDown={onPointerDown}
           className={dragging ? 'twk-seg dragging' : 'twk-seg'}>
        <div className="twk-seg-thumb"
             style={{ left: `calc(2px + ${idx} * (100% - 4px) / ${n})`,
                      width: `calc((100% - 4px) / ${n})` }} />
        {opts.map((o) => (
          <button key={o.value} type="button" role="radio" aria-checked={o.value === value}>
            {o.label}
          </button>
        ))}
      </div>
    </TweakRow>
  );
}

function TweakSelect({ label, value, options, onChange }) {
  return (
    <TweakRow label={label}>
      <select className="twk-field" value={value} onChange={(e) => onChange(e.target.value)}>
        {options.map((o) => {
          const v = typeof o === 'object' ? o.value : o;
          const l = typeof o === 'object' ? o.label : o;
          return <option key={v} value={v}>{l}</option>;
        })}
      </select>
    </TweakRow>
  );
}

function TweakText({ label, value, placeholder, onChange }) {
  return (
    <TweakRow label={label}>
      <input className="twk-field" type="text" value={value} placeholder={placeholder}
             onChange={(e) => onChange(e.target.value)} />
    </TweakRow>
  );
}

function TweakNumber({ label, value, min, max, step = 1, unit = '', onChange }) {
  const clamp = (n) => {
    if (min != null && n < min) return min;
    if (max != null && n > max) return max;
    return n;
  };
  const startRef = React.useRef({ x: 0, val: 0 });
  const onScrubStart = (e) => {
    e.preventDefault();
    startRef.current = { x: e.clientX, val: value };
    const decimals = (String(step).split('.')[1] || '').length;
    const move = (ev) => {
      const dx = ev.clientX - startRef.current.x;
      const raw = startRef.current.val + dx * step;
      const snapped = Math.round(raw / step) * step;
      onChange(clamp(Number(snapped.toFixed(decimals))));
    };
    const up = () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };
  return (
    <div className="twk-num">
      <span className="twk-num-lbl" onPointerDown={onScrubStart}>{label}</span>
      <input type="number" value={value} min={min} max={max} step={step}
             onChange={(e) => onChange(clamp(Number(e.target.value)))} />
      {unit && <span className="twk-num-unit">{unit}</span>}
    </div>
  );
}

function TweakColor({ label, value, onChange }) {
  return (
    <div className="twk-row twk-row-h">
      <div className="twk-lbl"><span>{label}</span></div>
      <input type="color" className="twk-swatch" value={value}
             onChange={(e) => onChange(e.target.value)} />
    </div>
  );
}

function TweakButton({ label, onClick, secondary = false }) {
  return (
    <button type="button" className={secondary ? 'twk-btn secondary' : 'twk-btn'}
            onClick={onClick}>{label}</button>
  );
}

Object.assign(window, {
  useTweaks, TweaksPanel, TweakSection, TweakRow,
  TweakSlider, TweakToggle, TweakRadio, TweakSelect,
  TweakText, TweakNumber, TweakColor, TweakButton,
});


// ═══ tokens.jsx ═══
// tokens.jsx — Cha-Tsing design system tokens
// Warm cream base, semantic color, type scale.

const CT_PALETTES = {
  cream: {
    bg:        '#FAEEDA',  // warm cream — Sunday morning
    bgSoft:    '#F5E2C5',
    bgCard:    '#FFF8EC',
    ink:       '#2A1F12',  // warm black, never pure
    inkSoft:   '#6B5640',
    inkMuted:  '#9C8870',
    line:      '#E8D4B0',
  },
  sage: {
    bg:        '#E8EFE5',
    bgSoft:    '#D8E3D2',
    bgCard:    '#F4F8F1',
    ink:       '#1F2A1A',
    inkSoft:   '#506049',
    inkMuted:  '#8C9A85',
    line:      '#C8D4C0',
  },
  rose: {
    bg:        '#F8E5DC',
    bgSoft:    '#F0D2C5',
    bgCard:    '#FFF1EA',
    ink:       '#2A1814',
    inkSoft:   '#6B4A40',
    inkMuted:  '#9C7A6E',
    line:      '#E8C8B8',
  },
  midnight: { // dark mode
    bg:        '#1C1812',
    bgSoft:    '#26211A',
    bgCard:    '#2E2820',
    ink:       '#FAEEDA',
    inkSoft:   '#C8B89E',
    inkMuted:  '#8C7E68',
    line:      '#3D352A',
  },
};

const CT_SEMANTIC = {
  // semantic, not decorative
  win:      '#22A06B',  // teal/green — savings, wins
  winSoft:  '#C5E8D5',
  danger:   '#E54B3C',  // coral — overspending
  dangerSoft:'#FBD3CD',
  dream:    '#7C4DFF',  // purple — aspirations
  dreamSoft:'#DCD0FF',
  amber:    '#C9854A',  // chico's fur tone
  amberSoft:'#F2D4B0',
};

const CT_TYPE = {
  // 'Fraunces' is in the avoid-list, but for a warm character app a friendly
  // serif works well. Use 'Inter' for sans; both are widely available.
  serif: '"Instrument Serif", "Times New Roman", Georgia, serif',
  sans:  'ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, sans-serif',
  mono:  'ui-monospace, "SF Mono", Menlo, monospace',
};

// Format peso amount with thousands separators
function peso(n, opts = {}) {
  const sign = n < 0 ? '-' : '';
  const v = Math.abs(Math.round(n));
  const s = v.toLocaleString('en-PH');
  return `${sign}₱${s}${opts.suffix || ''}`;
}

// Animated number counter hook
function useCountTo(target, duration = 600) {
  const [v, setV] = React.useState(target);
  const fromRef = React.useRef(target);
  const startRef = React.useRef(performance.now());

  React.useEffect(() => {
    fromRef.current = v;
    startRef.current = performance.now();
    let raf;
    const tick = () => {
      const t = Math.min(1, (performance.now() - startRef.current) / duration);
      const eased = 1 - Math.pow(1 - t, 3);
      const cur = fromRef.current + (target - fromRef.current) * eased;
      setV(cur);
      if (t < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
    // eslint-disable-next-line
  }, [target]);
  return v;
}

Object.assign(window, { CT_PALETTES, CT_SEMANTIC, CT_TYPE, peso, useCountTo });


// ═══ chico.jsx ═══
// chico.jsx — Chico the monkey, 5 expression states
// States: 'rich' | 'thriving' | 'okay' | 'stressed' | 'shocked'
// All SVG so it scales cleanly. Eyes/mouth morph based on state.

const CHICO_PALETTE = {
  fur: '#C9854A',         // amber/warm brown
  furDark: '#8E5A2D',
  furLight: '#E8B07A',
  face: '#F5D8B0',        // light face/belly
  faceShadow: '#E5BD8A',
  mouth: '#5C2E14',
  blush: '#F2A28A',
};

// Returns a complete Chico SVG component for a given state.
// size = px width, animate = whether to add idle bob
function Chico({ state = 'okay', size = 200, palette = CHICO_PALETTE, animate = true, savings = 0 }) {
  const p = palette;
  // expression-driven values
  const expr = CHICO_EXPRESSIONS[state] || CHICO_EXPRESSIONS.okay;

  return (
    <div style={{
      width: size, height: size, display: 'inline-block', position: 'relative',
      animation: animate ? 'chico-bob 2.4s ease-in-out infinite' : 'none',
    }}>
      <style>{`
        @keyframes chico-bob {
          0%, 100% { transform: translateY(0) rotate(-1deg); }
          50%     { transform: translateY(-4px) rotate(1deg); }
        }
        @keyframes chico-blink {
          0%, 92%, 100% { transform: scaleY(1); }
          95%, 97%      { transform: scaleY(0.05); }
        }
        @keyframes chico-money-rain {
          0%   { transform: translateY(-20px) rotate(-15deg); opacity: 0; }
          20%  { opacity: 1; }
          100% { transform: translateY(140px) rotate(25deg); opacity: 0; }
        }
        @keyframes chico-tear {
          0%   { transform: translateY(0); opacity: 0; }
          30%  { opacity: 1; }
          100% { transform: translateY(40px); opacity: 0; }
        }
        @keyframes chico-sweat {
          0%   { transform: translate(0,0) scale(0.5); opacity: 0; }
          30%  { opacity: 1; transform: translate(0,0) scale(1); }
          100% { transform: translate(4px,30px) scale(0.8); opacity: 0; }
        }
        @keyframes chico-sparkle {
          0%, 100% { transform: scale(0); opacity: 0; }
          50%      { transform: scale(1); opacity: 1; }
        }
        @keyframes chico-munch {
          0%, 100% { transform: scaleY(1) scaleX(1); }
          50%      { transform: scaleY(0.4) scaleX(1.1); }
        }
        @keyframes chico-reach {
          0%, 100% { transform: translateY(0); }
          50%      { transform: translateY(-3px); }
        }
        @keyframes chico-crumb {
          0%   { transform: translate(0, 0) rotate(0deg); opacity: 1; }
          100% { transform: translate(var(--cx, 30px), 40px) rotate(180deg); opacity: 0; }
        }
        .chico-eye { transform-box: fill-box; transform-origin: center; animation: chico-blink 4s ease-in-out infinite; }
      `}</style>
      <svg viewBox="0 0 200 200" width={size} height={size} style={{ overflow: 'visible' }}>
        <defs>
          <radialGradient id={`chico-fur-${state}`} cx="0.5" cy="0.4" r="0.7">
            <stop offset="0%" stopColor={p.furLight} />
            <stop offset="100%" stopColor={p.fur} />
          </radialGradient>
          <radialGradient id={`chico-face-${state}`} cx="0.5" cy="0.55" r="0.5">
            <stop offset="0%" stopColor="#FBE6C5" />
            <stop offset="100%" stopColor={p.face} />
          </radialGradient>
        </defs>

        {/* === Money rain (rich mode only) === */}
        {state === 'rich' && (
          <g>
            {[15, 35, 60, 78, 90, 120, 150, 175].map((x, i) => (
              <text key={i} x={x} y="0" fontSize={i % 2 ? 18 : 14} fill="#22A06B"
                    style={{ animation: `chico-money-rain ${1.4 + (i % 3) * 0.4}s ease-in ${i * 0.15}s infinite` }}>
                ₱
              </text>
            ))}
          </g>
        )}

        {/* === Sparkles (rich + thriving) === */}
        {(state === 'rich' || state === 'thriving') && (
          <g>
            {[[30, 50], [170, 60], [25, 110], [175, 130]].map(([cx, cy], i) => (
              <g key={i} transform={`translate(${cx} ${cy})`}
                 style={{ animation: `chico-sparkle 1.6s ease-in-out ${i * 0.3}s infinite`, transformBox: 'fill-box', transformOrigin: 'center' }}>
                <path d="M0 -6 L1.5 -1.5 L6 0 L1.5 1.5 L0 6 L-1.5 1.5 L-6 0 L-1.5 -1.5 Z"
                      fill={state === 'rich' ? '#22A06B' : '#FFB347'} />
              </g>
            ))}
          </g>
        )}

        {/* === Ears (behind head) === */}
        <ellipse cx="32" cy="78" rx="14" ry="18" fill={p.fur} />
        <ellipse cx="32" cy="78" rx="7" ry="10" fill={p.face} />
        <ellipse cx="168" cy="78" rx="14" ry="18" fill={p.fur} />
        <ellipse cx="168" cy="78" rx="7" ry="10" fill={p.face} />

        {/* === Body (peeking from below) === */}
        <ellipse cx="100" cy="200" rx="56" ry="36" fill={`url(#chico-fur-${state})`} />
        <ellipse cx="100" cy="200" rx="38" ry="22" fill={p.face} />

        {/* === Arms (state-driven pose) === */}
        {expr.arms === 'up' && (
          <g>
            <path d="M55 175 Q35 130, 50 95" stroke={p.fur} strokeWidth="18" strokeLinecap="round" fill="none" />
            <path d="M145 175 Q165 130, 150 95" stroke={p.fur} strokeWidth="18" strokeLinecap="round" fill="none" />
            <circle cx="50" cy="95" r="11" fill={p.face} />
            <circle cx="150" cy="95" r="11" fill={p.face} />
          </g>
        )}
        {expr.arms === 'cover' && (
          <g>
            <path d="M58 178 Q62 130, 82 110" stroke={p.fur} strokeWidth="18" strokeLinecap="round" fill="none" />
            <path d="M142 178 Q138 130, 118 110" stroke={p.fur} strokeWidth="18" strokeLinecap="round" fill="none" />
            <ellipse cx="82" cy="108" rx="13" ry="10" fill={p.face} />
            <ellipse cx="118" cy="108" rx="13" ry="10" fill={p.face} />
          </g>
        )}
        {expr.arms === 'side' && (
          <g>
            <path d="M58 175 Q40 165, 38 140" stroke={p.fur} strokeWidth="18" strokeLinecap="round" fill="none" />
            <path d="M142 175 Q160 165, 162 140" stroke={p.fur} strokeWidth="18" strokeLinecap="round" fill="none" />
            <circle cx="38" cy="140" r="11" fill={p.face} />
            <circle cx="162" cy="140" r="11" fill={p.face} />
          </g>
        )}
        {expr.arms === 'reach' && (
          <g style={{ animation: state === 'hungry' ? 'chico-reach 0.6s ease-in-out infinite' : 'none', transformOrigin: 'center bottom', transformBox: 'fill-box' }}>
            <path d="M58 175 Q50 145, 78 130" stroke={p.fur} strokeWidth="18" strokeLinecap="round" fill="none" />
            <path d="M142 175 Q150 145, 122 130" stroke={p.fur} strokeWidth="18" strokeLinecap="round" fill="none" />
            <circle cx="78" cy="128" r="12" fill={p.face} />
            <circle cx="122" cy="128" r="12" fill={p.face} />
          </g>
        )}

        {/* === Head === */}
        <ellipse cx="100" cy="100" rx="58" ry="55" fill={`url(#chico-fur-${state})`} />
        {/* face mask */}
        <ellipse cx="100" cy="108" rx="42" ry="40" fill={`url(#chico-face-${state})`} />
        {/* hair tuft */}
        <path d={expr.tuft || "M88 50 Q92 38, 100 42 Q108 38, 112 50 Q105 47, 100 50 Q95 47, 88 50 Z"}
              fill={p.furDark} />

        {/* === Brows === */}
        <g stroke={p.furDark} strokeWidth="3.5" strokeLinecap="round" fill="none">
          <path d={expr.browL} />
          <path d={expr.browR} />
        </g>

        {/* === Eyes === */}
        {expr.eyeShape === 'round' && (
          <g>
            <ellipse className="chico-eye" cx="82" cy="98" rx="7" ry={expr.eyeH || 8} fill="#1a1410" />
            <ellipse className="chico-eye" cx="118" cy="98" rx="7" ry={expr.eyeH || 8} fill="#1a1410" />
            <circle cx="84" cy="96" r="2" fill="#fff" />
            <circle cx="120" cy="96" r="2" fill="#fff" />
          </g>
        )}
        {expr.eyeShape === 'happy' && (
          <g stroke="#1a1410" strokeWidth="3.5" strokeLinecap="round" fill="none">
            <path d="M75 100 Q82 92, 89 100" />
            <path d="M111 100 Q118 92, 125 100" />
          </g>
        )}
        {expr.eyeShape === 'star' && (
          <g fill="#1a1410">
            {[[82, 98], [118, 98]].map(([cx, cy], i) => (
              <path key={i}
                d={`M${cx} ${cy - 9} L${cx + 2.5} ${cy - 2.5} L${cx + 9} ${cy} L${cx + 2.5} ${cy + 2.5} L${cx} ${cy + 9} L${cx - 2.5} ${cy + 2.5} L${cx - 9} ${cy} L${cx - 2.5} ${cy - 2.5} Z`} />
            ))}
          </g>
        )}
        {expr.eyeShape === 'shock' && (
          <g>
            <circle cx="82" cy="98" r="9" fill="#fff" stroke="#1a1410" strokeWidth="2" />
            <circle cx="118" cy="98" r="9" fill="#fff" stroke="#1a1410" strokeWidth="2" />
            <circle cx="82" cy="100" r="3.5" fill="#1a1410" />
            <circle cx="118" cy="100" r="3.5" fill="#1a1410" />
          </g>
        )}
        {expr.eyeShape === 'worried' && (
          <g>
            <ellipse cx="82" cy="100" rx="6" ry="7" fill="#1a1410" />
            <ellipse cx="118" cy="100" rx="6" ry="7" fill="#1a1410" />
            <circle cx="80" cy="97" r="1.8" fill="#fff" />
            <circle cx="116" cy="97" r="1.8" fill="#fff" />
            {/* tear */}
            <path d="M76 108 Q73 115, 76 120 Q79 115, 76 108 Z" fill="#7DD3FC"
                  style={{ animation: 'chico-tear 1.8s ease-in infinite', transformBox: 'fill-box' }} />
          </g>
        )}

        {/* === Sweat drops (stressed) === */}
        {state === 'stressed' && (
          <g>
            <path d="M148 80 Q146 76, 148 72 Q150 76, 148 80 Z" fill="#7DD3FC"
                  style={{ animation: 'chico-sweat 1.8s ease-in infinite', transformBox: 'fill-box' }} />
          </g>
        )}

        {/* === Blush === */}
        {expr.blush && (
          <g opacity="0.55">
            <ellipse cx="70" cy="118" rx="9" ry="5" fill={p.blush} />
            <ellipse cx="130" cy="118" rx="9" ry="5" fill={p.blush} />
          </g>
        )}

        {/* === Snout & mouth === */}
        <ellipse cx="100" cy="125" rx="20" ry="14" fill={p.faceShadow} opacity="0.4" />
        {/* nostrils */}
        <ellipse cx="95" cy="120" rx="1.5" ry="2.2" fill={p.furDark} />
        <ellipse cx="105" cy="120" rx="1.5" ry="2.2" fill={p.furDark} />

        {/* mouth shape */}
        <g>
          {expr.mouth === 'bigSmile' && (
            <path d="M82 132 Q100 150, 118 132 Q115 142, 100 144 Q85 142, 82 132 Z"
                  fill={p.mouth} />
          )}
          {expr.mouth === 'smile' && (
            <path d="M86 134 Q100 144, 114 134" stroke={p.mouth} strokeWidth="3" fill="none" strokeLinecap="round" />
          )}
          {expr.mouth === 'flat' && (
            <path d="M88 136 L112 136" stroke={p.mouth} strokeWidth="3" strokeLinecap="round" />
          )}
          {expr.mouth === 'frown' && (
            <path d="M86 140 Q100 130, 114 140" stroke={p.mouth} strokeWidth="3" fill="none" strokeLinecap="round" />
          )}
          {expr.mouth === 'oh' && (
            <ellipse cx="100" cy="138" rx="6" ry="8" fill={p.mouth} />
          )}
          {expr.mouth === 'open' && (
            <ellipse cx="100" cy="138" rx="10" ry="7" fill={p.mouth} />
          )}
          {expr.mouth === 'chomp' && (
            <g style={{ animation: 'chico-munch 0.32s ease-in-out infinite', transformBox: 'fill-box', transformOrigin: 'center' }}>
              <path d="M84 132 Q100 148, 116 132 Q116 140, 100 142 Q84 140, 84 132 Z" fill={p.mouth} />
              <path d="M88 134 L92 138 L96 134 L100 138 L104 134 L108 138 L112 134" stroke="#fff" strokeWidth="1.2" fill="none" />
            </g>
          )}
        </g>
      </svg>
    </div>
  );
}

const CHICO_EXPRESSIONS = {
  rich: {
    eyeShape: 'star',
    browL: 'M70 84 Q78 78, 90 82',
    browR: 'M110 82 Q122 78, 130 84',
    mouth: 'bigSmile',
    arms: 'up',
    blush: true,
    tuft: 'M86 48 Q90 35, 100 40 Q110 35, 114 48 Q105 45, 100 48 Q95 45, 86 48 Z',
  },
  thriving: {
    eyeShape: 'happy',
    browL: 'M72 86 Q80 82, 90 86',
    browR: 'M110 86 Q120 82, 128 86',
    mouth: 'smile',
    arms: 'side',
    blush: true,
  },
  okay: {
    eyeShape: 'round',
    eyeH: 8,
    browL: 'M72 88 L90 88',
    browR: 'M110 88 L128 88',
    mouth: 'flat',
    arms: 'side',
    blush: false,
  },
  stressed: {
    eyeShape: 'worried',
    browL: 'M72 84 Q80 90, 90 86',
    browR: 'M110 86 Q120 90, 128 84',
    mouth: 'frown',
    arms: 'cover',
    blush: false,
  },
  shocked: {
    eyeShape: 'shock',
    browL: 'M72 78 Q80 72, 90 76',
    browR: 'M110 76 Q120 72, 128 78',
    mouth: 'oh',
    arms: 'cover',
    blush: false,
  },
  eating: {
    eyeShape: 'happy',
    browL: 'M72 86 Q80 80, 90 86',
    browR: 'M110 86 Q120 80, 128 86',
    mouth: 'chomp',
    arms: 'reach',
    blush: true,
  },
  hungry: {
    eyeShape: 'round',
    eyeH: 9,
    browL: 'M72 84 Q80 80, 90 84',
    browR: 'M110 84 Q120 80, 128 84',
    mouth: 'open',
    arms: 'reach',
    blush: true,
  },
};

// Map savings % (0-1) to a Chico state.
function chicoStateFromSavings(pct) {
  if (pct >= 0.4) return 'rich';
  if (pct >= 0.25) return 'thriving';
  if (pct >= 0.12) return 'okay';
  if (pct >= 0.05) return 'stressed';
  return 'shocked';
}

// Lines Chico says, by state. English w/ playful monkey-character voice.
const CHICO_LINES = {
  rich: [
    "OOH-OOH-AAH! Banana stash secured! 🍌",
    "I'm seeing stars and they're all peso signs.",
    "Top of the tree, baby. Top. Of. The. Tree.",
    "This is how a wealthy monkey behaves.",
  ],
  thriving: [
    "Look at you, future-thinking primate.",
    "Steady swinging. I respect it.",
    "Ooh, this branch feels strong.",
    "Banana fund: thriving. Mood: chef's kiss.",
  ],
  okay: [
    "Eh, we're surviving. Could swing higher tho.",
    "Not bad. Not great. Very monkey.",
    "I'd save more bananas if I were you.",
    "We're fine. Define 'fine', though.",
  ],
  stressed: [
    "Uh. The branch is creaking, friend.",
    "I'm scratching my head. That's never a good sign.",
    "We need to talk about the banana situation.",
    "I'm not panicking. YOU'RE panicking.",
  ],
  shocked: [
    "OOK?! WHERE DID THE BANANAS GO?!",
    "I have seen things. Terrible, expensive things.",
    "*nervous monkey noises*",
    "This is not a drill. This is a banana emergency.",
  ],
};

function chicoLine(state, seed = 0) {
  const lines = CHICO_LINES[state] || CHICO_LINES.okay;
  return lines[seed % lines.length];
}

Object.assign(window, { Chico, CHICO_PALETTE, CHICO_EXPRESSIONS, CHICO_LINES, chicoStateFromSavings, chicoLine });


// ═══ chico-bubbles.jsx ═══
// chico-bubbles.jsx — draggable idea bubbles → drop on Chico → he eats them
// + long-press / tap "+" to open a hovering Edit Sheet (name, amount, recs)

const BUBBLE_LIBRARY = [
  { id: 'rent',       emoji: '🏠', label: 'Rent',         amount: 12000, color: '#7C4DFF', tip: "Most Pinoys spend 25-35% on housing. You?" },
  { id: 'groceries',  emoji: '🥬', label: 'Groceries',    amount: 6000,  color: '#22A06B', tip: "Palengke beats SM. Trust." },
  { id: 'transport',  emoji: '🛺', label: 'Transport',    amount: 3000,  color: '#C9854A', tip: "Grab + jeep + gas. All in here." },
  { id: 'fun',        emoji: '🎉', label: 'Fun money',    amount: 4000,  color: '#E54B3C', tip: "I won't tell anyone. Promise." },
  { id: 'gym',        emoji: '🏋', label: 'Gym',          amount: 1500,  color: '#22A06B', tip: "Banana strength training." },
  { id: 'streaming',  emoji: '📺', label: 'Streaming',    amount: 800,   color: '#7C4DFF', tip: "Netflix + Spotify + iWantTFC?" },
  { id: 'coffee',     emoji: '☕', label: 'Coffee',       amount: 2400,  color: '#C9854A', tip: "150/day = 4,500/mo. Just sayin'." },
  { id: 'family',     emoji: '👨‍👩‍👧', label: 'Family help', amount: 5000, color: '#E54B3C', tip: "Good kid energy." },
];

const RECOMMENDED_TEMPLATES = [
  { emoji: '🍱', label: 'Lunch out',     amount: 3000, color: '#C9854A' },
  { emoji: '💊', label: 'Meds & health', amount: 1200, color: '#22A06B' },
  { emoji: '🐕', label: 'Pet',           amount: 1500, color: '#C9854A' },
  { emoji: '📚', label: 'Books / Learn', amount: 1000, color: '#7C4DFF' },
  { emoji: '💇', label: 'Self-care',     amount: 1500, color: '#E54B3C' },
  { emoji: '🎁', label: 'Gifts',         amount: 1000, color: '#E54B3C' },
];

const ChicoDropContext = React.createContext(null);

// ── BubbleStage ─────────────────────────────────────────────────────────
function BubbleStage({ palette, children, allocations, onAdd, onRemove, onEditAllocation, chicoState, onChicoStateOverride }) {
  const p = palette;
  const stageRef = React.useRef(null);
  const chicoRefHolder = React.useRef(null);
  const setChicoRef = (r) => { chicoRefHolder.current = r; };

  const usedIds = new Set(allocations.map(a => a.id));
  const visibleBubbles = BUBBLE_LIBRARY.filter(b => !usedIds.has(b.id));

  const [drag, setDrag] = React.useState(null);
  const [chompPulse, setChompPulse] = React.useState(0);
  const [flash, setFlash] = React.useState(null);
  const [editing, setEditing] = React.useState(null); // bubble being edited
  const [near, setNear] = React.useState(false); // bubble close to chico → "hungry" override
  const [eating, setEating] = React.useState(false); // chomping for ~0.9s after drop

  // Long-press detection
  const longPressTimer = React.useRef(null);

  const startDrag = (bubble, e) => {
    e.preventDefault();
    const stage = stageRef.current;
    if (!stage) return;
    const r = stage.getBoundingClientRect();

    // start a long-press timer; if it fires before move/up, open editor
    let movedFar = false;
    const startX = e.clientX, startY = e.clientY;
    longPressTimer.current = setTimeout(() => {
      if (!movedFar) {
        setEditing({ ...bubble, mode: 'edit' });
        cleanup();
      }
    }, 360);

    setDrag({
      id: bubble.id, bubble,
      x: e.clientX - r.left, y: e.clientY - r.top,
    });

    const move = (ev) => {
      const dx = ev.clientX - startX, dy = ev.clientY - startY;
      if (Math.hypot(dx, dy) > 8) {
        movedFar = true;
        if (longPressTimer.current) { clearTimeout(longPressTimer.current); longPressTimer.current = null; }
      }
      const r2 = stage.getBoundingClientRect();
      setDrag(d => d ? { ...d, x: ev.clientX - r2.left, y: ev.clientY - r2.top } : null);

      // Near-Chico detection — when within ~80px of his center, he turns "hungry"
      const chicoEl = chicoRefHolder.current?.current;
      if (chicoEl) {
        const cr = chicoEl.getBoundingClientRect();
        const ccx = cr.left + cr.width / 2;
        const ccy = cr.top + cr.height / 2;
        const dist = Math.hypot(ev.clientX - ccx, ev.clientY - ccy);
        setNear(dist < Math.max(cr.width, cr.height) * 0.6 + 30);
      }
    };
    const cleanup = () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
      if (longPressTimer.current) { clearTimeout(longPressTimer.current); longPressTimer.current = null; }
      setDrag(null);
      setNear(false);
    };
    const up = (ev) => {
      const chicoEl = chicoRefHolder.current?.current;
      if (chicoEl && movedFar) {
        const cr = chicoEl.getBoundingClientRect();
        const hit = ev.clientX >= cr.left && ev.clientX <= cr.right
                  && ev.clientY >= cr.top  && ev.clientY <= cr.bottom;
        if (hit) {
          setChompPulse(p => p + 1);
          setEating(true);
          setTimeout(() => setEating(false), 900);
          setFlash(bubble);
          setTimeout(() => setFlash(null), 1400);
          onAdd(bubble);
        }
      }
      cleanup();
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };

  const openCustom = () => {
    setEditing({
      id: 'custom-' + Date.now(),
      emoji: '✨', label: 'New expense', amount: 2000, color: '#7C4DFF',
      mode: 'create',
    });
  };

  const saveEdit = (updated) => {
    onAdd(updated); // add (or replace if same id) to allocations
    setEditing(null);
    setChompPulse(p => p + 1);
    setEating(true);
    setTimeout(() => setEating(false), 900);
    setFlash(updated);
    setTimeout(() => setFlash(null), 1400);
  };

  // Notify parent of Chico state override (hungry while near, eating during chomp)
  const stateOverride = eating ? 'eating' : (near && drag) ? 'hungry' : null;
  React.useEffect(() => {
    if (onChicoStateOverride) onChicoStateOverride(stateOverride);
  }, [stateOverride, onChicoStateOverride]);

  let tracer = null;
  if (drag && chicoRefHolder.current?.current && stageRef.current) {
    const cr = chicoRefHolder.current.current.getBoundingClientRect();
    const sr = stageRef.current.getBoundingClientRect();
    tracer = {
      x1: drag.x, y1: drag.y,
      x2: cr.left + cr.width / 2 - sr.left,
      y2: cr.top + cr.height / 2 - sr.top,
    };
  }

  return (
    <ChicoDropContext.Provider value={{ setChicoRef, chompPulse, eating, near: near && !!drag, dragColor: drag?.bubble.color }}>
      <div ref={stageRef} style={{
        position: 'relative', flex: 1, display: 'flex', flexDirection: 'column',
        minHeight: 0, overflow: 'hidden',
      }}>
        {children}

        {/* Side rail */}
        <div style={{
          position: 'absolute', top: 60, right: 6, bottom: 80,
          display: 'flex', flexDirection: 'column', gap: 7, padding: '6px 4px',
          pointerEvents: 'none',
        }}>
          <div style={{
            fontSize: 9, color: p.inkMuted, textAlign: 'center',
            textTransform: 'uppercase', letterSpacing: 1, lineHeight: 1.2,
          }}>
            Drag<br/>to feed<br/>Chico
          </div>
          {visibleBubbles.slice(0, 5).map((b, i) => (
            <BubbleChip key={b.id} bubble={b} index={i}
              onPointerDown={(e) => startDrag(b, e)}
              hidden={drag?.id === b.id} />
          ))}
          {/* + Custom */}
          <button onClick={openCustom} style={{
            pointerEvents: 'auto', cursor: 'pointer',
            width: 52, height: 52, borderRadius: '50%', alignSelf: 'center',
            background: 'transparent', border: `2px dashed ${p.inkMuted}`,
            color: p.inkSoft, fontSize: 22, padding: 0,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }} title="Create custom expense">+</button>
        </div>

        {/* Hint banner during drag */}
        {drag && !tracer?.atTarget && (
          <div style={{
            position: 'absolute', bottom: 90, left: '50%', transform: 'translateX(-50%)',
            padding: '6px 12px', borderRadius: 999, background: 'rgba(0,0,0,0.7)',
            color: '#fff', fontSize: 11, pointerEvents: 'none', zIndex: 90,
          }}>
            Drop on Chico, or hold to edit
          </div>
        )}

        {/* Tracer */}
        {tracer && (
          <svg style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }}>
            <line x1={tracer.x1} y1={tracer.y1} x2={tracer.x2} y2={tracer.y2}
              stroke={drag.bubble.color} strokeWidth="2.5" strokeDasharray="4 6"
              opacity="0.7" strokeLinecap="round" />
            <circle cx={tracer.x2} cy={tracer.y2} r="22"
              fill="none" stroke={drag.bubble.color} strokeWidth="2" opacity="0.5">
              <animate attributeName="r" values="18;30;18" dur="0.9s" repeatCount="indefinite" />
              <animate attributeName="opacity" values="0.6;0.1;0.6" dur="0.9s" repeatCount="indefinite" />
            </circle>
          </svg>
        )}

        {drag && (
          <div style={{
            position: 'absolute', left: drag.x, top: drag.y,
            transform: 'translate(-50%, -50%) scale(1.15)',
            pointerEvents: 'none', zIndex: 100,
            filter: `drop-shadow(0 8px 16px ${drag.bubble.color}66)`,
          }}>
            <BubbleChipBody bubble={drag.bubble} active />
          </div>
        )}

        {flash && chicoRefHolder.current?.current && stageRef.current && (
          <FlashChip flash={flash}
            chicoRect={chicoRefHolder.current.current.getBoundingClientRect()}
            stageRect={stageRef.current.getBoundingClientRect()} />
        )}

        {/* Edit sheet — slides up over the screen, doesn't replace it */}
        {editing && (
          <BubbleEditSheet
            palette={p} bubble={editing}
            onSave={saveEdit}
            onCancel={() => setEditing(null)} />
        )}

        <style>{`
          @keyframes bubble-bob { 0%,100%{transform:translateY(0) rotate(-2deg);} 50%{transform:translateY(-3px) rotate(2deg);} }
          @keyframes flash-up {
            0%   { transform: translate(-50%, 0)    scale(0.4); opacity: 0; }
            20%  { transform: translate(-50%, -30px) scale(1.1); opacity: 1; }
            70%  { transform: translate(-50%, -38px) scale(1);   opacity: 1; }
            100% { transform: translate(-50%, -60px) scale(0.9); opacity: 0; }
          }
          @keyframes sheet-up {
            from { transform: translateY(100%); opacity: 0.6; }
            to   { transform: translateY(0);    opacity: 1; }
          }
          @keyframes scrim-in { from { opacity: 0; } to { opacity: 1; } }
        `}</style>
      </div>
    </ChicoDropContext.Provider>
  );
}

function BubbleChip({ bubble, index, onPointerDown, hidden }) {
  return (
    <div onPointerDown={onPointerDown}
      style={{
        pointerEvents: 'auto', cursor: 'grab', visibility: hidden ? 'hidden' : 'visible',
        animation: `bubble-bob ${2.4 + index * 0.2}s ease-in-out ${index * 0.15}s infinite`,
        alignSelf: 'center',
      }}>
      <BubbleChipBody bubble={bubble} />
    </div>
  );
}

function BubbleChipBody({ bubble, active = false }) {
  return (
    <div style={{
      width: 52, height: 52, borderRadius: '50%', background: '#fff',
      border: `2.5px solid ${bubble.color}`,
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
      boxShadow: active ? `0 6px 18px ${bubble.color}55` : '0 3px 8px rgba(42,31,18,0.12)',
      userSelect: 'none', position: 'relative',
    }}>
      <div style={{ fontSize: 19, lineHeight: 1 }}>{bubble.emoji}</div>
      <div style={{
        fontSize: 8, color: bubble.color, fontWeight: 700, marginTop: 1,
        fontVariantNumeric: 'tabular-nums', letterSpacing: 0.2,
      }}>
        ₱{(bubble.amount / 1000).toFixed(bubble.amount >= 10000 ? 0 : 1)}k
      </div>
    </div>
  );
}

function FlashChip({ flash, chicoRect, stageRect }) {
  const cx = chicoRect.left + chicoRect.width / 2 - stageRect.left;
  const cy = chicoRect.top - stageRect.top;
  return (
    <div style={{
      position: 'absolute', left: cx, top: cy, pointerEvents: 'none', zIndex: 50,
      animation: 'flash-up 1.4s cubic-bezier(.2,.8,.3,1) forwards',
    }}>
      <div style={{
        padding: '6px 14px', borderRadius: 999,
        background: flash.color, color: '#fff', fontSize: 12, fontWeight: 700,
        whiteSpace: 'nowrap', boxShadow: `0 8px 20px ${flash.color}66`,
      }}>
        +{flash.emoji} {flash.label} · ₱{flash.amount.toLocaleString()}
      </div>
    </div>
  );
}

// ── Edit Sheet — overlays without replacing screen ──────────────────────
const EMOJI_PALETTE = ['🏠','🥬','🛺','🎉','🏋','📺','☕','👨‍👩‍👧','🍱','💊','🐕','📚','💇','🎁','✨','💸','🚗','🍻','🎮','🛒'];
const COLOR_PALETTE = ['#7C4DFF','#22A06B','#C9854A','#E54B3C','#F2A28A','#7DD3FC'];

function BubbleEditSheet({ palette, bubble, onSave, onCancel }) {
  const p = palette;
  const [draft, setDraft] = React.useState(bubble);

  const update = (k, v) => setDraft(prev => ({ ...prev, [k]: v }));

  // Smart suggestion based on current amount
  const suggestion = React.useMemo(() => {
    if (draft.amount > 15000) return "Big-ticket. Make sure this is essential, friend.";
    if (draft.amount < 500) return "Tiny. Are you sure that's enough?";
    if (draft.label.toLowerCase().includes('coffee') && draft.amount > 3000) return "That's a lot of coffee. Or one fancy machine.";
    if (draft.label.toLowerCase().includes('rent') && draft.amount < 5000) return "Cheap rent! Bless.";
    return "Looks reasonable. Banana approved.";
  }, [draft.amount, draft.label]);

  return (
    <>
      {/* scrim */}
      <div onClick={onCancel} style={{
        position: 'absolute', inset: 0, background: 'rgba(20,15,8,0.45)',
        zIndex: 200, animation: 'scrim-in .2s ease',
        backdropFilter: 'blur(4px)', WebkitBackdropFilter: 'blur(4px)',
      }} />
      {/* sheet */}
      <div style={{
        position: 'absolute', left: 0, right: 0, bottom: 0, zIndex: 201,
        background: p.bg, borderTopLeftRadius: 24, borderTopRightRadius: 24,
        padding: '12px 20px 20px', boxShadow: '0 -20px 40px rgba(0,0,0,0.2)',
        animation: 'sheet-up .28s cubic-bezier(.2,.8,.3,1)',
        maxHeight: '90%', overflow: 'auto',
        fontFamily: CT_TYPE.sans, color: p.ink,
      }}>
        {/* grabber */}
        <div style={{
          width: 36, height: 4, borderRadius: 2, background: p.line,
          margin: '0 auto 12px',
        }} />

        {/* preview chip */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 14 }}>
          <BubbleChipBody bubble={draft} active />
          <div style={{ flex: 1, minWidth: 0 }}>
            <input
              type="text"
              value={draft.label}
              onChange={(e) => update('label', e.target.value)}
              style={{
                width: '100%', border: 'none', background: 'transparent',
                fontFamily: CT_TYPE.serif, fontSize: 24, color: p.ink, padding: 0,
                outline: 'none',
              }}
            />
            <div style={{ fontSize: 11, color: p.inkMuted, textTransform: 'uppercase', letterSpacing: 1, marginTop: 2 }}>
              {bubble.mode === 'create' ? 'Create expense' : 'Edit expense'}
            </div>
          </div>
        </div>

        {/* Amount — big tappable input + slider */}
        <div style={{
          padding: '12px 14px', borderRadius: 14,
          background: p.bgCard, border: `1px solid ${p.line}`,
        }}>
          <div style={{ fontSize: 11, color: p.inkMuted, textTransform: 'uppercase', letterSpacing: 1 }}>
            Amount per month
          </div>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 4, marginTop: 2 }}>
            <span style={{ fontSize: 24, color: p.inkSoft, fontFamily: CT_TYPE.serif }}>₱</span>
            <input
              type="number" min={0} max={100000} step={100}
              value={draft.amount}
              onChange={(e) => update('amount', Math.max(0, Math.min(100000, Number(e.target.value) || 0)))}
              style={{
                flex: 1, minWidth: 0, border: 'none', background: 'transparent',
                fontFamily: CT_TYPE.serif, fontSize: 32, color: draft.color, padding: 0,
                outline: 'none', fontVariantNumeric: 'tabular-nums', textAlign: 'right',
              }}
            />
          </div>

          {/* slider */}
          <input type="range" min={0} max={30000} step={100}
            value={Math.min(30000, draft.amount)}
            onChange={(e) => update('amount', Number(e.target.value))}
            style={{
              width: '100%', marginTop: 10, accentColor: draft.color,
              height: 6,
            }}
          />

          {/* preset chips */}
          <div style={{ display: 'flex', gap: 6, marginTop: 8, flexWrap: 'wrap' }}>
            {[1000, 2500, 5000, 10000, 15000].map(v => (
              <button key={v} onClick={() => update('amount', v)}
                style={{
                  padding: '4px 10px', borderRadius: 999,
                  border: `1px solid ${draft.amount === v ? draft.color : p.line}`,
                  background: draft.amount === v ? draft.color + '15' : 'transparent',
                  color: draft.amount === v ? draft.color : p.inkSoft,
                  fontSize: 11, cursor: 'pointer', fontWeight: 600,
                }}>
                ₱{(v/1000).toFixed(0)}k
              </button>
            ))}
          </div>
        </div>

        {/* Emoji picker */}
        <div style={{ marginTop: 14 }}>
          <div style={{ fontSize: 11, color: p.inkMuted, textTransform: 'uppercase', letterSpacing: 1, marginBottom: 6 }}>
            Icon
          </div>
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
            {EMOJI_PALETTE.map(e => (
              <button key={e} onClick={() => update('emoji', e)}
                style={{
                  width: 36, height: 36, borderRadius: 10,
                  border: `1.5px solid ${draft.emoji === e ? draft.color : 'transparent'}`,
                  background: draft.emoji === e ? '#fff' : p.bgCard,
                  fontSize: 18, cursor: 'pointer', padding: 0,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>{e}</button>
            ))}
          </div>
        </div>

        {/* Color */}
        <div style={{ marginTop: 14 }}>
          <div style={{ fontSize: 11, color: p.inkMuted, textTransform: 'uppercase', letterSpacing: 1, marginBottom: 6 }}>
            Color
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            {COLOR_PALETTE.map(c => (
              <button key={c} onClick={() => update('color', c)}
                style={{
                  width: 32, height: 32, borderRadius: '50%', background: c,
                  border: `3px solid ${draft.color === c ? p.ink : 'transparent'}`,
                  cursor: 'pointer', padding: 0,
                }} />
            ))}
          </div>
        </div>

        {/* Chico's recommendation */}
        <div style={{
          marginTop: 14, padding: '10px 12px', borderRadius: 12,
          background: CT_SEMANTIC.amberSoft, border: `1px solid ${CT_SEMANTIC.amber}33`,
          display: 'flex', gap: 10, alignItems: 'flex-start',
        }}>
          <div style={{ marginTop: -4, flexShrink: 0 }}>
            <Chico state="okay" size={44} animate={false} />
          </div>
          <div style={{ fontSize: 12, color: p.ink, lineHeight: 1.4 }}>
            <b>Chico says:</b> "{suggestion}"
            {bubble.tip && (
              <div style={{ marginTop: 4, color: p.inkSoft, fontStyle: 'italic' }}>
                Tip: {bubble.tip}
              </div>
            )}
          </div>
        </div>

        {/* Recommended templates */}
        {bubble.mode === 'create' && (
          <div style={{ marginTop: 14 }}>
            <div style={{ fontSize: 11, color: p.inkMuted, textTransform: 'uppercase', letterSpacing: 1, marginBottom: 6 }}>
              Or pick a template
            </div>
            <div style={{ display: 'flex', gap: 8, overflowX: 'auto', paddingBottom: 4 }}>
              {RECOMMENDED_TEMPLATES.map((t, i) => (
                <button key={i} onClick={() => setDraft(d => ({ ...d, ...t }))}
                  style={{
                    flexShrink: 0, padding: '8px 12px', borderRadius: 12,
                    border: `1px solid ${p.line}`, background: p.bgCard,
                    display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer',
                  }}>
                  <span style={{ fontSize: 18 }}>{t.emoji}</span>
                  <div style={{ textAlign: 'left' }}>
                    <div style={{ fontSize: 12, fontWeight: 600, color: p.ink }}>{t.label}</div>
                    <div style={{ fontSize: 10, color: t.color, fontWeight: 700 }}>₱{t.amount.toLocaleString()}</div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Actions */}
        <div style={{ display: 'flex', gap: 10, marginTop: 18 }}>
          <button onClick={onCancel} style={{
            flex: 1, padding: '13px', borderRadius: 14,
            background: 'transparent', border: `1px solid ${p.line}`,
            color: p.ink, fontSize: 14, fontWeight: 500, cursor: 'pointer',
          }}>Cancel</button>
          <button onClick={() => onSave(draft)} style={{
            flex: 2, padding: '13px', borderRadius: 14,
            background: p.ink, border: 'none', color: p.bg,
            fontSize: 14, fontWeight: 600, cursor: 'pointer',
          }}>
            {bubble.mode === 'create' ? 'Feed Chico →' : 'Save & feed →'}
          </button>
        </div>
      </div>
    </>
  );
}

// ── Allocation stack ────────────────────────────────────────────────────
function AllocationStack({ palette, allocations, onRemove, onEdit }) {
  const p = palette;
  if (!allocations.length) {
    return (
      <div style={{
        padding: '12px 14px', borderRadius: 14,
        border: `1.5px dashed ${p.line}`, background: 'transparent',
        fontSize: 12, color: p.inkMuted, textAlign: 'center', lineHeight: 1.4,
      }}>
        Drag a bubble → Chico, or tap <b>+</b> for custom
      </div>
    );
  }
  const total = allocations.reduce((s, a) => s + a.amount, 0);
  return (
    <div style={{
      padding: '10px 12px', borderRadius: 14,
      background: p.bgCard, border: `1px solid ${p.line}`,
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 6 }}>
        <span style={{ fontSize: 10, color: p.inkMuted, textTransform: 'uppercase', letterSpacing: 1 }}>
          Chico's allocations · tap to edit
        </span>
        <span style={{ fontSize: 12, color: p.ink, fontVariantNumeric: 'tabular-nums', fontWeight: 600 }}>
          ₱{total.toLocaleString()}
        </span>
      </div>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
        {allocations.map(a => (
          <span key={a.id} style={{
            display: 'flex', alignItems: 'center', gap: 5,
            padding: '4px 4px 4px 6px', borderRadius: 999,
            background: '#fff', border: `1px solid ${a.color}55`,
            fontSize: 11, color: p.ink, fontFamily: CT_TYPE.sans,
          }}>
            <button onClick={() => onEdit && onEdit(a)} style={{
              border: 'none', background: 'transparent', padding: 0, cursor: 'pointer',
              display: 'flex', alignItems: 'center', gap: 5, color: 'inherit', font: 'inherit',
            }}>
              <span style={{ fontSize: 13 }}>{a.emoji}</span>
              <span style={{ fontWeight: 500 }}>{a.label}</span>
              <span style={{ color: a.color, fontWeight: 700, fontVariantNumeric: 'tabular-nums' }}>
                ₱{(a.amount/1000).toFixed(a.amount >= 10000 ? 0 : 1)}k
              </span>
            </button>
            <button onClick={() => onRemove(a.id)} style={{
              border: 'none', background: 'transparent', cursor: 'pointer',
              color: p.inkMuted, padding: '0 4px', fontSize: 14, lineHeight: 1,
            }}>×</button>
          </span>
        ))}
      </div>
    </div>
  );
}

function DroppableChico({ state, size }) {
  const wrapRef = React.useRef(null);
  const ctx = React.useContext(ChicoDropContext);
  const [chomp, setChomp] = React.useState(0);
  const [crumbs, setCrumbs] = React.useState([]);

  React.useEffect(() => { if (ctx?.setChicoRef) ctx.setChicoRef(wrapRef); }, [ctx]);
  React.useEffect(() => {
    if (ctx?.chompPulse) {
      setChomp(c => c + 1);
      // spawn crumbs
      const id = Date.now();
      const newCrumbs = Array.from({ length: 6 }, (_, i) => ({
        id: id + i,
        cx: (Math.random() - 0.5) * 80,
        delay: i * 60,
        color: ctx.dragColor || '#C9854A',
      }));
      setCrumbs(c => [...c, ...newCrumbs]);
      setTimeout(() => setCrumbs(c => c.filter(x => !newCrumbs.find(n => n.id === x.id))), 1200);
      const t = setTimeout(() => setChomp(c => c + 1), 320);
      return () => clearTimeout(t);
    }
  }, [ctx?.chompPulse]);

  // override Chico's state if context says so
  const effectiveState = ctx?.eating ? 'eating' : ctx?.near ? 'hungry' : state;

  return (
    <div ref={wrapRef} style={{
      display: 'inline-block', position: 'relative',
      animation: chomp % 2 === 1 ? 'chico-chomp 0.32s cubic-bezier(.2,.8,.3,1)' : 'none',
      transformOrigin: 'center bottom',
    }}>
      <style>{`
        @keyframes chico-chomp {
          0%   { transform: scale(1); }
          40%  { transform: scale(1.12, 0.92); }
          70%  { transform: scale(0.96, 1.05); }
          100% { transform: scale(1); }
        }
      `}</style>
      <Chico state={effectiveState} size={size} />
      {/* crumb particles */}
      {crumbs.map(c => (
        <span key={c.id} style={{
          position: 'absolute', left: '50%', top: '60%',
          width: 6, height: 6, borderRadius: 2, background: c.color,
          '--cx': `${c.cx}px`,
          animation: `chico-crumb 0.9s ease-out ${c.delay}ms forwards`,
          pointerEvents: 'none',
        }} />
      ))}
    </div>
  );
}

Object.assign(window, {
  BUBBLE_LIBRARY, BubbleStage, AllocationStack, DroppableChico, ChicoDropContext, BubbleEditSheet,
});


// ═══ screen-onboarding.jsx ═══
// screens.jsx — Four core screens for Cha-Tsing
// 1. Onboarding  2. Savings slider  3. Dream tracker  4. Insights

// ─────────────────────────────────────────────────────────────
// Shared chrome — soft top bar
// ─────────────────────────────────────────────────────────────
function CTHeader({ palette, title, right, onBack }) {
  const p = palette;
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 12,
      padding: '14px 18px 6px',
    }}>
      {onBack ? (
        <button onClick={onBack} style={{
          width: 36, height: 36, borderRadius: 18, border: 'none',
          background: p.bgCard, color: p.ink, fontSize: 18, cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>←</button>
      ) : (
        <div style={{
          width: 36, height: 36, borderRadius: 12, background: CT_SEMANTIC.amber,
          color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontFamily: CT_TYPE.serif, fontSize: 22, fontWeight: 600,
        }}>C</div>
      )}
      <div style={{ flex: 1, fontFamily: CT_TYPE.sans, fontSize: 14, color: p.inkSoft }}>
        {title}
      </div>
      {right}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// 1. ONBOARDING — "Hi, I'm Chico"
// ─────────────────────────────────────────────────────────────
function OnboardingScreen({ palette, income, onIncomeChange, onContinue }) {
  const p = palette;
  const [step, setStep] = React.useState(0);
  const [draft, setDraft] = React.useState(income);

  const takeHome = Math.round(draft * 0.84); // rough deduction estimate

  return (
    <div style={{
      flex: 1, background: p.bg, fontFamily: CT_TYPE.sans, color: p.ink,
      display: 'flex', flexDirection: 'column', overflow: 'hidden',
    }}>
      <CTHeader palette={p} title="Welcome" />

      {/* Chico hero */}
      <div style={{
        display: 'flex', justifyContent: 'center', padding: '8px 0 0',
      }}>
        <Chico state="thriving" size={180} />
      </div>

      {step === 0 && (
        <div style={{ padding: '12px 28px 0', flex: 1, display: 'flex', flexDirection: 'column' }}>
          <div style={{ fontFamily: CT_TYPE.serif, fontSize: 38, lineHeight: 1.05, color: p.ink, textWrap: 'pretty' }}>
            Hi, I'm Chico.
          </div>
          <div style={{ fontSize: 16, color: p.inkSoft, marginTop: 14, lineHeight: 1.5 }}>
            I'm a monkey who's seen some things. Mostly bananas. Sometimes money.
            Tell me what you bring home and I'll tell you how stressed I am about it.
          </div>
          <div style={{ flex: 1 }} />
          <CTButton palette={p} onClick={() => setStep(1)} label="Okay, fine" />
          <div style={{ height: 18 }} />
        </div>
      )}

      {step === 1 && (
        <div style={{ padding: '12px 28px 0', flex: 1, display: 'flex', flexDirection: 'column' }}>
          <div style={{ fontFamily: CT_TYPE.serif, fontSize: 28, lineHeight: 1.1 }}>
            What's your gross monthly?
          </div>
          <div style={{ fontSize: 14, color: p.inkSoft, marginTop: 8 }}>
            Before the government takes its share. I won't judge. (I will judge.)
          </div>

          <div style={{
            marginTop: 22, padding: '18px 18px',
            background: p.bgCard, borderRadius: 18, border: `1px solid ${p.line}`,
          }}>
            <div style={{ fontSize: 12, color: p.inkMuted, textTransform: 'uppercase', letterSpacing: 1 }}>
              Gross monthly
            </div>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 4, marginTop: 4 }}>
              <span style={{ fontSize: 28, color: p.inkSoft, fontFamily: CT_TYPE.serif }}>₱</span>
              <input
                type="number"
                value={draft}
                onChange={e => setDraft(Number(e.target.value) || 0)}
                style={{
                  flex: 1, border: 'none', background: 'transparent',
                  fontSize: 38, fontFamily: CT_TYPE.serif, color: p.ink,
                  outline: 'none', minWidth: 0, padding: 0,
                }}
              />
            </div>
            <div style={{
              marginTop: 14, paddingTop: 14, borderTop: `1px dashed ${p.line}`,
              display: 'flex', justifyContent: 'space-between', alignItems: 'center',
            }}>
              <span style={{ fontSize: 12, color: p.inkMuted, textTransform: 'uppercase', letterSpacing: 1 }}>
                Take-home (est.)
              </span>
              <span style={{ fontSize: 18, fontFamily: CT_TYPE.serif, color: CT_SEMANTIC.win }}>
                {peso(takeHome)}
              </span>
            </div>
          </div>

          {/* quick presets */}
          <div style={{ display: 'flex', gap: 8, marginTop: 14, flexWrap: 'wrap' }}>
            {[25000, 40000, 60000, 90000, 120000].map(v => (
              <button key={v}
                onClick={() => setDraft(v)}
                style={{
                  padding: '8px 12px', borderRadius: 999,
                  border: `1px solid ${p.line}`,
                  background: draft === v ? p.ink : 'transparent',
                  color: draft === v ? p.bg : p.inkSoft,
                  fontSize: 13, cursor: 'pointer', fontFamily: CT_TYPE.sans,
                }}>
                {peso(v).replace('₱', '₱')}
              </button>
            ))}
          </div>

          <div style={{ flex: 1 }} />
          <CTButton palette={p} onClick={() => { onIncomeChange(draft); onContinue(); }} label="Show me the damage →" />
          <div style={{ height: 18 }} />
        </div>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Reusable button
// ─────────────────────────────────────────────────────────────
function CTButton({ palette, onClick, label, variant = 'primary' }) {
  const p = palette;
  const isPrimary = variant === 'primary';
  return (
    <button onClick={onClick} style={{
      width: '100%', padding: '16px 22px',
      borderRadius: 18, border: 'none',
      background: isPrimary ? p.ink : 'transparent',
      color: isPrimary ? p.bg : p.ink,
      fontSize: 16, fontWeight: 600, fontFamily: CT_TYPE.sans,
      cursor: 'pointer', letterSpacing: 0.2,
      boxShadow: isPrimary ? '0 8px 24px rgba(42,31,18,0.25)' : 'none',
      transition: 'transform .15s ease',
    }}
    onMouseDown={e => e.currentTarget.style.transform = 'scale(0.98)'}
    onMouseUp={e => e.currentTarget.style.transform = 'scale(1)'}
    onMouseLeave={e => e.currentTarget.style.transform = 'scale(1)'}
    >{label}</button>
  );
}

Object.assign(window, { CTHeader, CTButton, OnboardingScreen });


// ═══ screen-slider.jsx ═══
// screen-slider.jsx — THE HERO INTERACTION
// Drag the savings slider, watch Chico's face morph in real time.

function SavingsSliderScreen({
  palette, income, savingsPct, onSavingsChange,
  forcedState = null, variant = 'classic', onNext, onBack,
  allocations = [], onAddAllocation, onRemoveAllocation,
}) {
  const p = palette;
  const takeHome = Math.round(income * 0.84);

  // Allocations eat into spendable money, so the *effective* savings target is
  // user's slider applied to (take-home - allocations). Drag-to-add bubbles
  // therefore directly squeeze Chico's mood.
  const allocTotal = allocations.reduce((s, a) => s + a.amount, 0);
  const remaining = Math.max(0, takeHome - allocTotal);
  const savingsAmount = Math.round(remaining * savingsPct);
  const spendingAmount = remaining - savingsAmount;

  // True savings rate (vs gross take-home, not remaining) for Chico's mood
  const truePct = takeHome > 0 ? savingsAmount / takeHome : 0;
  const state = forcedState || chicoStateFromSavings(truePct);

  const animSavings = useCountTo(savingsAmount, 350);
  const animSpending = useCountTo(spendingAmount, 350);

  const [seed, setSeed] = React.useState(0);
  const lastStateRef = React.useRef(state);
  React.useEffect(() => {
    if (lastStateRef.current !== state) {
      setSeed(s => s + 1);
      lastStateRef.current = state;
    }
  }, [state]);

  const line = chicoLine(state, seed);

  return (
    <div style={{
      flex: 1, background: p.bg, fontFamily: CT_TYPE.sans, color: p.ink,
      display: 'flex', flexDirection: 'column', overflow: 'hidden',
    }}>
      <CTHeader palette={p} title="How much will you save?" onBack={onBack} />

      <BubbleStage palette={p} allocations={allocations}
        onAdd={onAddAllocation} onRemove={onRemoveAllocation}
        onEditAllocation={onAddAllocation}>
        {variant === 'classic' && (
          <ClassicLayout p={p} state={state} line={line}
            animSavings={animSavings} animSpending={animSpending}
            savingsPct={savingsPct} onSavingsChange={onSavingsChange}
            takeHome={takeHome} onNext={onNext}
            allocations={allocations} onRemoveAllocation={onRemoveAllocation} />
        )}
        {variant === 'split' && (
          <SplitLayout p={p} state={state} line={line}
            animSavings={animSavings} animSpending={animSpending}
            savingsPct={savingsPct} onSavingsChange={onSavingsChange}
            takeHome={takeHome} onNext={onNext}
            allocations={allocations} onRemoveAllocation={onRemoveAllocation} />
        )}
        {variant === 'dial' && (
          <DialLayout p={p} state={state} line={line}
            animSavings={animSavings} animSpending={animSpending}
            savingsPct={savingsPct} onSavingsChange={onSavingsChange}
            takeHome={takeHome} onNext={onNext}
            allocations={allocations} onRemoveAllocation={onRemoveAllocation} />
        )}
      </BubbleStage>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Variant A: Classic — Chico hero, big slider
// ─────────────────────────────────────────────────────────────
function ClassicLayout({ p, state, line, animSavings, animSpending, savingsPct, onSavingsChange, takeHome, onNext, allocations, onRemoveAllocation }) {
  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', padding: '4px 80px 0 24px' }}>
      {/* Chico stage — droppable target for bubbles */}
      <div style={{
        position: 'relative', display: 'flex', justifyContent: 'center', alignItems: 'flex-end',
        height: 200, marginTop: 4,
      }}>
        <DroppableChico state={state} size={180} palette={p} />
      </div>

      {/* Speech bubble */}
      <SpeechBubble p={p} text={line} state={state} />

      {/* Big number */}
      <div style={{ textAlign: 'center', marginTop: 14 }}>
        <div style={{
          fontFamily: CT_TYPE.serif, fontSize: 56, lineHeight: 1, color: p.ink,
          fontVariantNumeric: 'tabular-nums', letterSpacing: -1,
        }}>
          {peso(animSavings)}
        </div>
        <div style={{ fontSize: 13, color: p.inkSoft, marginTop: 6, letterSpacing: 0.4 }}>
          to save · <span style={{ color: CT_SEMANTIC.win, fontWeight: 600 }}>{Math.round(savingsPct * 100)}%</span> of take-home
        </div>
      </div>

      {/* Slider */}
      <div style={{ marginTop: 20, padding: '0 4px' }}>
        <FatSlider value={savingsPct} onChange={onSavingsChange} state={state} p={p} />
        <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 8, fontSize: 11, color: p.inkMuted, letterSpacing: 0.5 }}>
          <span>0%</span>
          <span>20%</span>
          <span>40%</span>
          <span>60%+</span>
        </div>
      </div>

      {/* allocations stack — populated by drag-to-Chico */}
      <div style={{ marginTop: 14 }}>
        <AllocationStack palette={p} allocations={allocations} onRemove={onRemoveAllocation} />
      </div>

      <div style={{ flex: 1 }} />
      <CTButton palette={p} label="Lock it in →" onClick={onNext} />
      <div style={{ height: 16 }} />
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Variant B: Split — money split visualization, sliding partition
// ─────────────────────────────────────────────────────────────
function SplitLayout({ p, state, line, animSavings, animSpending, savingsPct, onSavingsChange, takeHome, onNext, allocations, onRemoveAllocation }) {
  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', padding: '4px 80px 0 24px' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginTop: 6 }}>
        <DroppableChico state={state} size={120} palette={p} />
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 11, color: p.inkMuted, textTransform: 'uppercase', letterSpacing: 1 }}>
            Take-home
          </div>
          <div style={{ fontFamily: CT_TYPE.serif, fontSize: 32, lineHeight: 1, color: p.ink }}>
            {peso(takeHome)}
          </div>
          <div style={{
            marginTop: 8, fontSize: 13, color: p.inkSoft, lineHeight: 1.4,
            fontStyle: 'italic',
          }}>
            "{line}"
          </div>
        </div>
      </div>

      {/* Split bar */}
      <div style={{ marginTop: 22 }}>
        <div style={{
          display: 'flex', height: 72, borderRadius: 16, overflow: 'hidden',
          border: `1px solid ${p.line}`, position: 'relative',
        }}>
          <div style={{
            width: `${savingsPct * 100}%`, background: CT_SEMANTIC.win,
            display: 'flex', flexDirection: 'column', justifyContent: 'center',
            padding: '0 14px', transition: 'width .25s ease', minWidth: 0,
          }}>
            <div style={{ fontSize: 10, color: 'rgba(255,255,255,.85)', textTransform: 'uppercase', letterSpacing: 1 }}>
              Save
            </div>
            <div style={{ fontFamily: CT_TYPE.serif, fontSize: 18, color: '#fff', fontVariantNumeric: 'tabular-nums', whiteSpace: 'nowrap' }}>
              {peso(animSavings)}
            </div>
          </div>
          <div style={{
            flex: 1, background: CT_SEMANTIC.amberSoft,
            display: 'flex', flexDirection: 'column', justifyContent: 'center',
            padding: '0 14px', alignItems: 'flex-end', minWidth: 0,
          }}>
            <div style={{ fontSize: 10, color: p.inkSoft, textTransform: 'uppercase', letterSpacing: 1 }}>
              Spend
            </div>
            <div style={{ fontFamily: CT_TYPE.serif, fontSize: 18, color: p.ink, fontVariantNumeric: 'tabular-nums', whiteSpace: 'nowrap' }}>
              {peso(animSpending)}
            </div>
          </div>
        </div>

        <div style={{ marginTop: 22 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 6 }}>
            <span style={{ fontSize: 13, color: p.inkSoft }}>Drag to adjust</span>
            <span style={{ fontFamily: CT_TYPE.serif, fontSize: 28, color: p.ink, fontVariantNumeric: 'tabular-nums' }}>
              {Math.round(savingsPct * 100)}%
            </span>
          </div>
          <FatSlider value={savingsPct} onChange={onSavingsChange} state={state} p={p} />
        </div>
      </div>

      {/* annual ticker */}
      <div style={{
        marginTop: 18, padding: 18, borderRadius: 18,
        background: state === 'rich' ? CT_SEMANTIC.winSoft :
                    state === 'shocked' ? CT_SEMANTIC.dangerSoft : p.bgCard,
        border: `1px solid ${p.line}`, transition: 'background .25s',
      }}>
        <div style={{ fontSize: 12, color: p.inkSoft, textTransform: 'uppercase', letterSpacing: 1 }}>
          In 12 months you'll have
        </div>
        <div style={{
          fontFamily: CT_TYPE.serif, fontSize: 42, color: p.ink, marginTop: 4,
          fontVariantNumeric: 'tabular-nums', letterSpacing: -0.5,
        }}>
          {peso(animSavings * 12)}
        </div>
        <div style={{ fontSize: 13, color: p.inkSoft, marginTop: 4 }}>
          That's {Math.round((animSavings * 12) / 5000)} round-trip flights to Cebu, give or take.
        </div>
      </div>

      <div style={{ marginTop: 14 }}>
        <AllocationStack palette={p} allocations={allocations} onRemove={onRemoveAllocation} />
      </div>

      <div style={{ flex: 1 }} />
      <CTButton palette={p} label="Lock it in →" onClick={onNext} />
      <div style={{ height: 16 }} />
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Variant C: Dial — radial gauge wraps Chico
// ─────────────────────────────────────────────────────────────
function DialLayout({ p, state, line, animSavings, animSpending, savingsPct, onSavingsChange, takeHome, onNext, allocations, onRemoveAllocation }) {
  const dialRef = React.useRef(null);
  const [dragging, setDragging] = React.useState(false);

  // Map angle (-135deg to +135deg) to pct (0 to 1)
  const angleAt = (clientX, clientY) => {
    if (!dialRef.current) return savingsPct;
    const r = dialRef.current.getBoundingClientRect();
    const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
    const dx = clientX - cx, dy = clientY - cy;
    let a = Math.atan2(dx, -dy) * 180 / Math.PI; // -180..180, 0=top
    a = Math.max(-135, Math.min(135, a));
    return (a + 135) / 270;
  };

  const onPointerDown = (e) => {
    setDragging(true);
    onSavingsChange(angleAt(e.clientX, e.clientY));
    const move = (ev) => onSavingsChange(angleAt(ev.clientX, ev.clientY));
    const up = () => {
      setDragging(false);
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };

  // Arc paths
  const R = 110, CX = 130, CY = 130;
  const angleDeg = -135 + savingsPct * 270;
  const angleRad = (angleDeg - 90) * Math.PI / 180;
  const handleX = CX + R * Math.cos(angleRad);
  const handleY = CY + R * Math.sin(angleRad);

  const arcPath = (start, end) => {
    const sR = (start - 90) * Math.PI / 180;
    const eR = (end - 90) * Math.PI / 180;
    const x1 = CX + R * Math.cos(sR), y1 = CY + R * Math.sin(sR);
    const x2 = CX + R * Math.cos(eR), y2 = CY + R * Math.sin(eR);
    const large = end - start > 180 ? 1 : 0;
    return `M ${x1} ${y1} A ${R} ${R} 0 ${large} 1 ${x2} ${y2}`;
  };

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', padding: '4px 80px 0 24px', alignItems: 'center' }}>
      <div ref={dialRef} onPointerDown={onPointerDown}
        style={{
          position: 'relative', width: 260, height: 260, marginTop: 6,
          touchAction: 'none', cursor: dragging ? 'grabbing' : 'grab',
        }}>
        <svg width="260" height="260" viewBox="0 0 260 260" style={{ position: 'absolute', inset: 0 }}>
          {/* track */}
          <path d={arcPath(-135, 135)} fill="none" stroke={p.line} strokeWidth="14" strokeLinecap="round" />
          {/* fill */}
          <path d={arcPath(-135, angleDeg)} fill="none"
                stroke={state === 'shocked' || state === 'stressed' ? CT_SEMANTIC.danger : CT_SEMANTIC.win}
                strokeWidth="14" strokeLinecap="round" style={{ transition: 'stroke .25s' }} />
          {/* tick marks at 25/50/75 */}
          {[0.25, 0.5, 0.75].map((t, i) => {
            const a = (-135 + t * 270 - 90) * Math.PI / 180;
            const x1 = CX + (R - 12) * Math.cos(a), y1 = CY + (R - 12) * Math.sin(a);
            const x2 = CX + (R + 12) * Math.cos(a), y2 = CY + (R + 12) * Math.sin(a);
            return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke={p.inkMuted} strokeWidth="1" />;
          })}
          {/* handle */}
          <circle cx={handleX} cy={handleY} r="14" fill="#fff"
                  stroke={state === 'shocked' || state === 'stressed' ? CT_SEMANTIC.danger : CT_SEMANTIC.win}
                  strokeWidth="3" />
        </svg>

        {/* Chico in center — droppable */}
        <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', pointerEvents: 'none' }}>
          <DroppableChico state={state} size={150} palette={p} />
        </div>
      </div>

      <div style={{ textAlign: 'center', marginTop: 4 }}>
        <div style={{ fontFamily: CT_TYPE.serif, fontSize: 44, color: p.ink, lineHeight: 1, fontVariantNumeric: 'tabular-nums', letterSpacing: -0.5 }}>
          {Math.round(savingsPct * 100)}%
        </div>
        <div style={{ fontSize: 13, color: p.inkSoft, marginTop: 4 }}>
          {peso(animSavings)} · per month
        </div>
      </div>

      {/* speech */}
      <div style={{
        marginTop: 14, padding: '12px 18px', borderRadius: 999,
        background: p.bgCard, border: `1px solid ${p.line}`,
        fontSize: 13, color: p.ink, fontStyle: 'italic', maxWidth: 320, textAlign: 'center',
      }}>
        "{line}"
      </div>

      <div style={{ width: '100%', marginTop: 14 }}>
        <AllocationStack palette={p} allocations={allocations} onRemove={onRemoveAllocation} />
      </div>

      <div style={{ flex: 1 }} />
      <div style={{ width: '100%' }}>
        <CTButton palette={p} label="Lock it in →" onClick={onNext} />
      </div>
      <div style={{ height: 16 }} />
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// FatSlider — custom slider that's chunky and snappy
// ─────────────────────────────────────────────────────────────
function FatSlider({ value, onChange, state, p, max = 0.6 }) {
  const trackRef = React.useRef(null);
  const [dragging, setDragging] = React.useState(false);

  const valueAt = (clientX) => {
    if (!trackRef.current) return value;
    const r = trackRef.current.getBoundingClientRect();
    const t = (clientX - r.left) / r.width;
    return Math.max(0, Math.min(max, t * max));
  };

  const onPointerDown = (e) => {
    setDragging(true);
    onChange(valueAt(e.clientX));
    const move = (ev) => onChange(valueAt(ev.clientX));
    const up = () => {
      setDragging(false);
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };

  const pct = (value / max) * 100;
  const fillColor =
    state === 'rich'     ? CT_SEMANTIC.win :
    state === 'thriving' ? CT_SEMANTIC.win :
    state === 'okay'     ? CT_SEMANTIC.amber :
    state === 'stressed' ? CT_SEMANTIC.danger :
    /* shocked */          CT_SEMANTIC.danger;

  return (
    <div ref={trackRef} onPointerDown={onPointerDown}
      style={{
        position: 'relative', height: 44, cursor: dragging ? 'grabbing' : 'grab',
        touchAction: 'none', userSelect: 'none',
      }}>
      <div style={{
        position: 'absolute', left: 0, right: 0, top: '50%', transform: 'translateY(-50%)',
        height: 14, borderRadius: 999, background: p.line,
      }} />
      <div style={{
        position: 'absolute', left: 0, top: '50%', transform: 'translateY(-50%)',
        height: 14, width: `${pct}%`, borderRadius: 999, background: fillColor,
        transition: dragging ? 'none' : 'background .25s',
      }} />
      <div style={{
        position: 'absolute', left: `${pct}%`, top: '50%',
        transform: 'translate(-50%, -50%)',
        width: 32, height: 32, borderRadius: '50%', background: '#fff',
        border: `3px solid ${fillColor}`,
        boxShadow: '0 4px 12px rgba(0,0,0,0.18)',
        transition: dragging ? 'none' : 'border-color .25s',
      }} />
    </div>
  );
}

// Speech bubble with state-driven color
function SpeechBubble({ p, text, state }) {
  const bg = p.bgCard;
  return (
    <div style={{
      margin: '4px auto 0', maxWidth: 320, padding: '10px 16px',
      background: bg, border: `1px solid ${p.line}`,
      borderRadius: 18, position: 'relative',
      fontSize: 14, color: p.ink, textAlign: 'center', fontStyle: 'italic',
      lineHeight: 1.35,
    }}>
      <div style={{
        position: 'absolute', top: -7, left: '50%', transform: 'translateX(-50%) rotate(45deg)',
        width: 12, height: 12, background: bg,
        borderTop: `1px solid ${p.line}`, borderLeft: `1px solid ${p.line}`,
      }} />
      "{text}"
    </div>
  );
}

Object.assign(window, { SavingsSliderScreen, FatSlider, SpeechBubble });


// ═══ screen-dreams.jsx ═══
// screen-dreams.jsx — Dream tracker with blur-to-clear photo reveal

const DREAM_LIBRARY = [
  { id: 'boracay',  emoji: '🏝',  label: 'Boracay trip',     target: 45000,   tone: 'aspirational',
    img: 'linear-gradient(135deg, #7DD3FC 0%, #FED7AA 60%, #FECACA 100%)' }, // tropical
  { id: 'iphone',   emoji: '📱',  label: 'New phone',         target: 65000,   tone: 'aspirational',
    img: 'linear-gradient(135deg, #1F2937 0%, #4B5563 50%, #9CA3AF 100%)' },
  { id: 'condo',    emoji: '🏢',  label: 'Condo down payment',target: 350000,  tone: 'practical',
    img: 'linear-gradient(160deg, #93C5FD 0%, #DBEAFE 40%, #F3F4F6 100%)' },
  { id: 'japan',    emoji: '⛩',  label: 'Japan trip',        target: 120000,  tone: 'aspirational',
    img: 'linear-gradient(135deg, #FCA5A5 0%, #FECACA 50%, #FEF3C7 100%)' },
  { id: 'emergency',emoji: '🛟',  label: 'Emergency fund',    target: 180000,  tone: 'practical',
    img: 'linear-gradient(135deg, #34D399 0%, #A7F3D0 50%, #FEF3C7 100%)' },
  { id: 'wedding',  emoji: '💍',  label: 'Wedding',           target: 400000,  tone: 'practical',
    img: 'linear-gradient(135deg, #F9A8D4 0%, #FBCFE8 50%, #FEF3C7 100%)' },
];

function DreamTrackerScreen({ palette, monthlySavings, onBack, onNext }) {
  const p = palette;
  const [activeId, setActiveId] = React.useState('boracay');
  const [progress, setProgress] = React.useState({
    boracay: 0.65, iphone: 0.32, condo: 0.08, japan: 0.18, emergency: 0.42, wedding: 0.05,
  });

  const active = DREAM_LIBRARY.find(d => d.id === activeId);
  const pct = progress[activeId] || 0;
  const saved = Math.round(active.target * pct);
  const monthsLeft = monthlySavings > 0 ? Math.ceil((active.target - saved) / monthlySavings) : 99;

  const animSaved = useCountTo(saved, 500);
  const animPct = useCountTo(pct, 500);

  // blur amount inverse to progress: 0% = 24px blur, 100% = 0px
  const blurPx = (1 - animPct) * 22;
  const grayscale = (1 - animPct) * 80;

  return (
    <div style={{
      flex: 1, background: p.bg, fontFamily: CT_TYPE.sans, color: p.ink,
      display: 'flex', flexDirection: 'column', overflow: 'hidden',
    }}>
      <CTHeader palette={p} title="Your dreams" onBack={onBack} />

      {/* hero card with blurred photo */}
      <div style={{ padding: '4px 24px 0' }}>
        <div style={{
          position: 'relative', height: 240, borderRadius: 22, overflow: 'hidden',
          border: `1px solid ${p.line}`, boxShadow: '0 12px 30px rgba(42,31,18,0.12)',
        }}>
          {/* blurred 'photo' (CSS gradient placeholder, behaves like a photo) */}
          <div style={{
            position: 'absolute', inset: -30,
            background: active.img,
            filter: `blur(${blurPx}px) grayscale(${grayscale}%)`,
            transition: 'filter .5s ease',
          }} />
          {/* mono striped placeholder pattern overlay (drop here for real photo) */}
          <div style={{
            position: 'absolute', inset: 0,
            background: 'repeating-linear-gradient(45deg, transparent 0 12px, rgba(255,255,255,0.04) 12px 24px)',
            mixBlendMode: 'overlay',
          }} />
          {/* darken at bottom for legibility */}
          <div style={{
            position: 'absolute', left: 0, right: 0, bottom: 0, height: 120,
            background: 'linear-gradient(180deg, transparent, rgba(0,0,0,0.55))',
          }} />
          {/* big emoji center, fades out as it clears */}
          <div style={{
            position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 80, opacity: Math.max(0.25, 1 - animPct),
            transition: 'opacity .5s', filter: `drop-shadow(0 4px 12px rgba(0,0,0,0.25))`,
          }}>
            {active.emoji}
          </div>
          {/* label */}
          <div style={{ position: 'absolute', left: 16, right: 16, bottom: 14, color: '#fff' }}>
            <div style={{ fontSize: 11, opacity: 0.85, textTransform: 'uppercase', letterSpacing: 1.5 }}>
              Coming into focus
            </div>
            <div style={{ fontFamily: CT_TYPE.serif, fontSize: 26, lineHeight: 1.1 }}>
              {active.label}
            </div>
          </div>
          {/* progress chip top-right */}
          <div style={{
            position: 'absolute', top: 14, right: 14,
            padding: '6px 12px', borderRadius: 999,
            background: 'rgba(255,255,255,0.92)', backdropFilter: 'blur(8px)',
            fontSize: 13, fontWeight: 600, color: p.ink, fontVariantNumeric: 'tabular-nums',
          }}>
            {Math.round(animPct * 100)}%
          </div>
        </div>

        {/* numbers row */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginTop: 14 }}>
          <div>
            <div style={{ fontSize: 11, color: p.inkMuted, textTransform: 'uppercase', letterSpacing: 1 }}>Saved</div>
            <div style={{ fontFamily: CT_TYPE.serif, fontSize: 24, color: p.ink, fontVariantNumeric: 'tabular-nums' }}>
              {peso(animSaved)}
            </div>
          </div>
          <div style={{ textAlign: 'right' }}>
            <div style={{ fontSize: 11, color: p.inkMuted, textTransform: 'uppercase', letterSpacing: 1 }}>Goal</div>
            <div style={{ fontFamily: CT_TYPE.serif, fontSize: 24, color: p.inkSoft, fontVariantNumeric: 'tabular-nums' }}>
              {peso(active.target)}
            </div>
          </div>
        </div>

        {/* months countdown */}
        <div style={{
          marginTop: 12, padding: '10px 14px', borderRadius: 12,
          background: p.bgCard, border: `1px solid ${p.line}`,
          display: 'flex', alignItems: 'center', gap: 10, fontSize: 13, color: p.inkSoft,
        }}>
          <Chico state={pct >= 0.5 ? 'thriving' : 'okay'} size={36} animate={false} />
          <span>
            At <b style={{ color: p.ink }}>{peso(monthlySavings)}/mo</b>, ~
            <b style={{ color: CT_SEMANTIC.dream }}> {monthsLeft} months</b> until banana time.
          </span>
        </div>
      </div>

      {/* dream picker */}
      <div style={{ marginTop: 18, padding: '0 24px 6px', fontSize: 12, color: p.inkMuted, textTransform: 'uppercase', letterSpacing: 1 }}>
        Switch dream
      </div>
      <div style={{
        display: 'flex', gap: 10, padding: '4px 24px 8px', overflowX: 'auto',
        scrollbarWidth: 'none',
      }}>
        {DREAM_LIBRARY.map(d => {
          const isActive = d.id === activeId;
          const dpct = progress[d.id] || 0;
          return (
            <button key={d.id} onClick={() => setActiveId(d.id)}
              style={{
                flexShrink: 0, width: 110, padding: '10px 12px',
                borderRadius: 14, border: `1px solid ${isActive ? p.ink : p.line}`,
                background: isActive ? p.ink : p.bgCard,
                color: isActive ? p.bg : p.ink,
                cursor: 'pointer', textAlign: 'left',
                fontFamily: CT_TYPE.sans,
              }}>
              <div style={{ fontSize: 22 }}>{d.emoji}</div>
              <div style={{ fontSize: 12, marginTop: 4, fontWeight: 600, lineHeight: 1.2 }}>{d.label}</div>
              <div style={{
                marginTop: 6, height: 4, borderRadius: 2,
                background: isActive ? 'rgba(255,255,255,0.2)' : p.line,
                overflow: 'hidden',
              }}>
                <div style={{ height: '100%', width: `${dpct * 100}%`, background: CT_SEMANTIC.dream }} />
              </div>
            </button>
          );
        })}
      </div>

      {/* simulate progress */}
      <div style={{ padding: '8px 24px 0' }}>
        <div style={{ fontSize: 12, color: p.inkMuted, marginBottom: 6, letterSpacing: 0.4 }}>
          Drag to preview future progress
        </div>
        <FatSlider
          value={pct} max={1}
          onChange={(v) => setProgress(prev => ({ ...prev, [activeId]: v }))}
          state={pct >= 0.5 ? 'thriving' : 'okay'} p={p} />
      </div>

      <div style={{ flex: 1 }} />
      <div style={{ padding: '0 24px 16px' }}>
        <CTButton palette={p} label="See my insights →" onClick={onNext} />
      </div>
    </div>
  );
}

Object.assign(window, { DreamTrackerScreen, DREAM_LIBRARY });


// ═══ screen-insights.jsx ═══
// screen-insights.jsx — Insights / dashboard

function InsightsScreen({ palette, income, savingsPct, onBack, onRestart, onTalk }) {
  const p = palette;
  const takeHome = Math.round(income * 0.84);
  const monthly = Math.round(takeHome * savingsPct);
  const annual = monthly * 12;
  const state = chicoStateFromSavings(savingsPct);

  // fake spending breakdown
  const spend = takeHome - monthly;
  const categories = [
    { label: 'Rent & bills', pct: 0.42, color: '#7C4DFF' },
    { label: 'Food & groceries', pct: 0.22, color: '#22A06B' },
    { label: 'Transport', pct: 0.10, color: '#C9854A' },
    { label: 'Fun stuff', pct: 0.16, color: '#E54B3C' },
    { label: 'Other', pct: 0.10, color: '#9C8870' },
  ];

  const insights = [
    {
      title: state === 'rich' ? "You're saving like a banana baron" :
             state === 'thriving' ? "You're outsaving most of your peers" :
             state === 'okay' ? "You're saving less than the recommended 20%" :
             state === 'stressed' ? "You're cutting it pretty close" :
             "We need to have a chat",
      body: state === 'rich' ? `At this pace you'll hit a million in ${Math.ceil(1000000/monthly)} months. I'm proud. I'm a proud monkey.` :
            state === 'thriving' ? `Your annual rate of ${peso(annual)} compounds beautifully. Keep climbing.` :
            state === 'okay' ? `Bumping savings to 20% would mean ${peso(takeHome*0.2)}/mo — that's ${peso((takeHome*0.2 - monthly)*12)} more per year.` :
            state === 'stressed' ? `Less than 12% is risky territory. One emergency could undo a year of progress.` :
            `Saving under 5% means no buffer. Let's find ₱2,000/mo to start. I believe in you.`,
      tone: state === 'rich' || state === 'thriving' ? 'win' : state === 'okay' ? 'amber' : 'danger',
    },
    {
      title: "Your biggest leak is 'fun stuff'",
      body: `You're spending around ${peso(spend * 0.16)}/mo on lifestyle. Halving that adds ${peso(spend * 0.08 * 12)}/year to savings. I'm not saying don't have fun. I'm saying have 50% less of it.`,
      tone: 'amber',
    },
    {
      title: "If you started today",
      body: `By age 60 (assuming 6% growth), this rate compounds to roughly ${peso(annual * 38)}. That's a coconut farm. Maybe two.`,
      tone: 'win',
    },
  ];

  return (
    <div style={{
      flex: 1, background: p.bg, fontFamily: CT_TYPE.sans, color: p.ink,
      display: 'flex', flexDirection: 'column', overflow: 'auto',
    }}>
      <CTHeader palette={p} title="Insights" onBack={onBack} />

      {/* Top: Chico + headline */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '4px 24px 0' }}>
        <Chico state={state} size={110} />
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 12, color: p.inkMuted, textTransform: 'uppercase', letterSpacing: 1 }}>
            This month, Chico says
          </div>
          <div style={{ fontFamily: CT_TYPE.serif, fontSize: 22, lineHeight: 1.15, color: p.ink, marginTop: 4 }}>
            {state === 'rich' ? "Magnificent." :
             state === 'thriving' ? "We're doing the thing." :
             state === 'okay' ? "We could do better." :
             state === 'stressed' ? "I'm worried." :
             "Banana red alert."}
          </div>
        </div>
      </div>

      {/* Big savings card */}
      <div style={{ padding: '14px 24px 0' }}>
        <div style={{
          padding: 18, borderRadius: 20, background: p.bgCard, border: `1px solid ${p.line}`,
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
            <span style={{ fontSize: 12, color: p.inkMuted, textTransform: 'uppercase', letterSpacing: 1 }}>
              Saving rate
            </span>
            <span style={{ fontSize: 12, color: CT_SEMANTIC.win, fontWeight: 600 }}>
              {Math.round(savingsPct * 100)}%
            </span>
          </div>
          <div style={{
            fontFamily: CT_TYPE.serif, fontSize: 38, color: p.ink, marginTop: 4,
            fontVariantNumeric: 'tabular-nums', letterSpacing: -0.5,
          }}>
            {peso(monthly)} <span style={{ fontSize: 14, color: p.inkSoft }}>/mo</span>
          </div>

          {/* spending bar */}
          <div style={{ marginTop: 16 }}>
            <div style={{
              display: 'flex', height: 12, borderRadius: 6, overflow: 'hidden',
            }}>
              {categories.map((c, i) => (
                <div key={i} style={{ flex: c.pct, background: c.color }} />
              ))}
            </div>
            <div style={{ marginTop: 10, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
              {categories.map((c, i) => (
                <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 11, color: p.inkSoft }}>
                  <span style={{ width: 8, height: 8, borderRadius: 2, background: c.color }} />
                  <span style={{ flex: 1 }}>{c.label}</span>
                  <span style={{ fontVariantNumeric: 'tabular-nums', color: p.inkMuted }}>{Math.round(c.pct * 100)}%</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Insight cards */}
      <div style={{ padding: '14px 24px 0', display: 'flex', flexDirection: 'column', gap: 10 }}>
        <div style={{ fontSize: 12, color: p.inkMuted, textTransform: 'uppercase', letterSpacing: 1 }}>
          Chico's takes
        </div>
        {insights.map((ins, i) => {
          const accent = ins.tone === 'win' ? CT_SEMANTIC.win :
                         ins.tone === 'danger' ? CT_SEMANTIC.danger :
                         CT_SEMANTIC.amber;
          return (
            <div key={i} style={{
              padding: '14px 16px', borderRadius: 16,
              background: p.bgCard, border: `1px solid ${p.line}`,
              position: 'relative', overflow: 'hidden',
            }}>
              <div style={{
                position: 'absolute', top: 0, left: 0, bottom: 0, width: 4, background: accent,
              }} />
              <div style={{ paddingLeft: 6 }}>
                <div style={{ fontFamily: CT_TYPE.serif, fontSize: 17, color: p.ink, lineHeight: 1.2 }}>
                  {ins.title}
                </div>
                <div style={{ fontSize: 13, color: p.inkSoft, marginTop: 6, lineHeight: 1.45 }}>
                  {ins.body}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div style={{ flex: 1, minHeight: 18 }} />
      <div style={{ padding: '0 24px 18px', display: 'flex', gap: 10 }}>
        <button onClick={onBack} style={{
          flex: 1, padding: '14px', borderRadius: 16,
          background: 'transparent', border: `1px solid ${p.line}`,
          color: p.ink, fontFamily: CT_TYPE.sans, fontSize: 15, fontWeight: 500, cursor: 'pointer',
        }}>← Adjust</button>
        <button onClick={onTalk} style={{
          flex: 1.4, padding: '14px', borderRadius: 16,
          background: p.ink, border: 'none',
          color: p.bg, fontFamily: CT_TYPE.sans, fontSize: 15, fontWeight: 600, cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
        }}><span style={{ fontSize: 18 }}>🐒</span> Talk to Chico</button>
      </div>
    </div>
  );
}

Object.assign(window, { InsightsScreen });


// ═══ screen-coach.jsx ═══
// screen-coach.jsx — post-insights chat with Chico + editable budget

function CoachScreen({
  palette, income, savingsPct, onSavingsChange,
  allocations, onAddAllocation, onRemoveAllocation,
  onBack,
}) {
  const p = palette;
  const takeHome = Math.round(income * 0.84);
  const allocTotal = allocations.reduce((s, a) => s + a.amount, 0);
  const remaining = Math.max(0, takeHome - allocTotal);
  const savingsAmt = Math.round(remaining * savingsPct);
  const truePct = takeHome > 0 ? savingsAmt / takeHome : 0;
  const state = chicoStateFromSavings(truePct);

  const [messages, setMessages] = React.useState([
    { from: 'chico', text: "Hey, real talk. Want to plan how we hit your goal?" },
  ]);
  const [showAdjuster, setShowAdjuster] = React.useState(false);
  const [adjusting, setAdjusting] = React.useState(null); // alloc being edited
  const [unexpected, setUnexpected] = React.useState(null); // 'gain'|'loss'

  const log = (msg) => setMessages(m => [...m, msg]);

  const ask = (q) => {
    log({ from: 'me', text: q.label });
    setTimeout(() => log({ from: 'chico', text: q.reply }), 350);
  };

  const QUICK = [
    { label: "Can I hit ₱100k this year?",
      reply: takeHome * 12 * 0.18 >= 100000
        ? `At your pace, ₱${(savingsAmt * 12).toLocaleString()}/yr. You're on track. 🍌`
        : `Right now: ₱${(savingsAmt * 12).toLocaleString()}/yr. Need to bump savings ~5% or trim a bubble.` },
    { label: "What should I cut first?",
      reply: allocations.length === 0
        ? "Nothing to cut yet — drag some expenses in first."
        : `Honestly? '${[...allocations].sort((a,b)=>b.amount-a.amount)[0].label}' is your biggest one. Worth a look.` },
    { label: "I got a raise!",
      reply: "Niiice. Tap the income field — bump it up, and I'll reflect it everywhere." },
    { label: "Surprise expense came up",
      reply: "Happens. Tap any bubble in your list to adjust it, or add a new one." },
  ];

  return (
    <div style={{
      flex: 1, background: p.bg, fontFamily: CT_TYPE.sans, color: p.ink,
      display: 'flex', flexDirection: 'column', overflow: 'hidden', minHeight: 0,
    }}>
      <CTHeader palette={p} title="Talk to Chico" onBack={onBack} />

      {/* Chico header card */}
      <div style={{
        margin: '4px 20px 0', padding: '14px 16px', borderRadius: 18,
        background: p.bgCard, border: `1px solid ${p.line}`,
        display: 'flex', gap: 14, alignItems: 'center',
      }}>
        <Chico state={state} size={72} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 11, color: p.inkMuted, textTransform: 'uppercase', letterSpacing: 1 }}>
            Saving rate
          </div>
          <div style={{ fontFamily: CT_TYPE.serif, fontSize: 28, color: p.ink, lineHeight: 1, fontVariantNumeric: 'tabular-nums' }}>
            {Math.round(truePct * 100)}%
          </div>
          <div style={{ fontSize: 12, color: p.inkSoft, marginTop: 4 }}>
            ₱{savingsAmt.toLocaleString()}/mo · ₱{(savingsAmt * 12).toLocaleString()}/yr
          </div>
        </div>
      </div>

      {/* Conversation */}
      <div style={{
        flex: 1, overflow: 'auto', padding: '14px 20px',
        display: 'flex', flexDirection: 'column', gap: 8, minHeight: 0,
      }}>
        {messages.map((m, i) => (
          <div key={i} style={{
            alignSelf: m.from === 'me' ? 'flex-end' : 'flex-start',
            maxWidth: '82%',
            padding: '9px 13px', borderRadius: 16,
            background: m.from === 'me' ? p.ink : p.bgCard,
            color: m.from === 'me' ? p.bg : p.ink,
            border: m.from === 'me' ? 'none' : `1px solid ${p.line}`,
            fontSize: 13, lineHeight: 1.45,
            borderBottomRightRadius: m.from === 'me' ? 4 : 16,
            borderBottomLeftRadius: m.from === 'me' ? 16 : 4,
          }}>{m.text}</div>
        ))}
      </div>

      {/* Quick replies */}
      <div style={{ padding: '0 20px 8px', display: 'flex', gap: 6, flexWrap: 'wrap' }}>
        {QUICK.map((q, i) => (
          <button key={i} onClick={() => ask(q)} style={{
            padding: '7px 12px', borderRadius: 999,
            background: 'transparent', border: `1px solid ${p.line}`,
            color: p.ink, fontSize: 11, cursor: 'pointer', fontFamily: CT_TYPE.sans,
          }}>{q.label}</button>
        ))}
      </div>

      {/* Unexpected event row */}
      <div style={{
        margin: '0 20px 8px', padding: '10px 12px', borderRadius: 14,
        background: CT_SEMANTIC.amberSoft, border: `1px solid ${CT_SEMANTIC.amber}33`,
        display: 'flex', alignItems: 'center', gap: 10,
      }}>
        <span style={{ fontSize: 18 }}>⚡</span>
        <div style={{ flex: 1, fontSize: 12, color: p.ink, lineHeight: 1.3 }}>
          Something change today?
        </div>
        <button onClick={() => setShowAdjuster(true)} style={{
          padding: '6px 12px', borderRadius: 999, border: 'none',
          background: p.ink, color: p.bg, fontSize: 11, fontWeight: 600, cursor: 'pointer',
        }}>Adjust budget</button>
      </div>

      <div style={{ padding: '0 20px 18px' }}>
        <CTButton palette={p} label="Done · back to insights" onClick={onBack} />
      </div>

      {/* Adjuster sheet */}
      {showAdjuster && (
        <BudgetAdjusterSheet
          palette={p}
          allocations={allocations}
          savingsPct={savingsPct}
          onSavingsChange={onSavingsChange}
          onEditAlloc={(a) => { setAdjusting(a); }}
          onRemove={onRemoveAllocation}
          onClose={() => setShowAdjuster(false)} />
      )}
      {adjusting && (
        <BubbleEditSheet palette={p} bubble={{ ...adjusting, mode: 'edit' }}
          onSave={(u) => { onAddAllocation(u); setAdjusting(null); }}
          onCancel={() => setAdjusting(null)} />
      )}
    </div>
  );
}

function BudgetAdjusterSheet({ palette, allocations, savingsPct, onSavingsChange, onEditAlloc, onRemove, onClose }) {
  const p = palette;
  return (
    <>
      <div onClick={onClose} style={{
        position: 'absolute', inset: 0, background: 'rgba(20,15,8,0.45)',
        zIndex: 200, animation: 'scrim-in .2s ease',
        backdropFilter: 'blur(4px)', WebkitBackdropFilter: 'blur(4px)',
      }} />
      <div style={{
        position: 'absolute', left: 0, right: 0, bottom: 0, zIndex: 201,
        background: p.bg, borderTopLeftRadius: 24, borderTopRightRadius: 24,
        padding: '12px 20px 20px', boxShadow: '0 -20px 40px rgba(0,0,0,0.2)',
        animation: 'sheet-up .28s cubic-bezier(.2,.8,.3,1)',
        maxHeight: '85%', overflow: 'auto',
      }}>
        <div style={{ width: 36, height: 4, borderRadius: 2, background: p.line, margin: '0 auto 12px' }} />
        <div style={{ fontFamily: CT_TYPE.serif, fontSize: 22, color: p.ink, marginBottom: 4 }}>
          Adjust on the fly
        </div>
        <div style={{ fontSize: 12, color: p.inkSoft, marginBottom: 14, lineHeight: 1.4 }}>
          Got a bonus or a surprise bill? Tweak any expense, or shift your savings rate.
        </div>

        {/* Savings slider */}
        <div style={{ padding: '12px 14px', borderRadius: 14, background: p.bgCard, border: `1px solid ${p.line}` }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
            <span style={{ fontSize: 11, color: p.inkMuted, textTransform: 'uppercase', letterSpacing: 1 }}>Savings rate</span>
            <span style={{ fontFamily: CT_TYPE.serif, fontSize: 22, color: CT_SEMANTIC.win, fontVariantNumeric: 'tabular-nums' }}>
              {Math.round(savingsPct * 100)}%
            </span>
          </div>
          <input type="range" min={0} max={0.6} step={0.01} value={savingsPct}
            onChange={(e) => onSavingsChange(Number(e.target.value))}
            style={{ width: '100%', marginTop: 8, accentColor: CT_SEMANTIC.win }} />
        </div>

        {/* Expense list */}
        <div style={{ marginTop: 14, fontSize: 11, color: p.inkMuted, textTransform: 'uppercase', letterSpacing: 1, marginBottom: 6 }}>
          Your expenses · tap to edit
        </div>
        {allocations.length === 0 ? (
          <div style={{ fontSize: 12, color: p.inkMuted, padding: '14px', textAlign: 'center', border: `1.5px dashed ${p.line}`, borderRadius: 14 }}>
            None yet — go add a bubble.
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            {allocations.map(a => (
              <div key={a.id} style={{
                display: 'flex', alignItems: 'center', gap: 10,
                padding: '10px 12px', borderRadius: 12,
                background: p.bgCard, border: `1px solid ${p.line}`,
              }}>
                <span style={{ fontSize: 22 }}>{a.emoji}</span>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 13, fontWeight: 600, color: p.ink }}>{a.label}</div>
                  <div style={{ fontSize: 11, color: a.color, fontVariantNumeric: 'tabular-nums', fontWeight: 700 }}>
                    ₱{a.amount.toLocaleString()}/mo
                  </div>
                </div>
                <button onClick={() => onEditAlloc(a)} style={{
                  padding: '6px 10px', borderRadius: 999, border: `1px solid ${p.line}`,
                  background: 'transparent', color: p.ink, fontSize: 11, cursor: 'pointer',
                }}>Edit</button>
                <button onClick={() => onRemove(a.id)} style={{
                  border: 'none', background: 'transparent', color: p.inkMuted,
                  fontSize: 18, cursor: 'pointer', padding: 4,
                }}>×</button>
              </div>
            ))}
          </div>
        )}

        <button onClick={onClose} style={{
          width: '100%', marginTop: 16, padding: '13px', borderRadius: 14,
          background: p.ink, border: 'none', color: p.bg,
          fontSize: 14, fontWeight: 600, cursor: 'pointer',
        }}>Done</button>
      </div>
    </>
  );
}

Object.assign(window, { CoachScreen, BudgetAdjusterSheet });

